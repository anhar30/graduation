<?php
require_once __DIR__ . '/config/database.php';

// Keamanan: Cek apakah siswa sudah login
if (!isset($_SESSION['student_id'])) {
    $_SESSION['login_error'] = 'Silakan masukkan NISN dan Tanggal Lahir terlebih dahulu!';
    header('Location: index.php');
    exit;
}

// Mendapatkan data siswa berdasarkan ID di Session
try {
    $stmt = $pdo->prepare("SELECT * FROM students WHERE id = :id");
    $stmt->execute(['id' => $_SESSION['student_id']]);
    $student = $stmt->fetch();
    
    if (!$student || $student['status_kelulusan'] !== 'LULUS') {
        // Jika data hilang atau status ternyata tidak lulus
        header('Location: hasil.php');
        exit;
    }
} catch (PDOException $e) {
    die("Kesalahan sistem dalam memuat cetak SKL!");
}

// Mendapatkan pengaturan sekolah
$settings = getAllSettings();
$namaSekolah = $settings['nama_sekolah'] ?? 'SD Negeri Cerdas Bangsa';
$tahunAjaran = $settings['tahun_ajaran'] ?? '2025/2026';
$namaKepsek = $settings['nama_kepsek'] ?? 'Drs. Budi Santoso, M.Pd.';
$nipKepsek = $settings['nip_kepsek'] ?? '19750812 200003 1 002';
$alamatSekolah = $settings['alamat_sekolah'] ?? 'Jl. Pendidikan No. 45, Jakarta Pusat';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cetak SKL - <?= htmlspecialchars($student['nama']) ?></title>
    <!-- Google Fonts untuk Tampilan Cetak Resmi -->
    <link href="https://fonts.googleapis.com/css2?family=Times+New+Roman&family=Plus+Jakarta+Sans:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* CSS GAYA UTAMA UNTUK DOKUMEN RESMI (Gaya Cetak Kertas A4) */
        :root {
            --font-official: 'Times New Roman', Times, serif;
            --font-ui: 'Plus Jakarta Sans', sans-serif;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background-color: #f3f4f6;
            color: #111827;
            font-family: var(--font-official);
            line-height: 1.5;
            padding-bottom: 3rem;
        }

        /* Navigasi Cetak di Layar */
        .print-nav {
            background-color: #1e1b4b;
            color: white;
            padding: 1rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 100;
            box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1);
            font-family: var(--font-ui);
        }

        .print-nav-title {
            font-weight: 700;
            font-size: 1.1rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .print-nav-buttons {
            display: flex;
            gap: 0.8rem;
        }

        .btn-nav {
            padding: 0.5rem 1.2rem;
            border-radius: 8px;
            font-size: 0.9rem;
            font-weight: 600;
            cursor: pointer;
            border: none;
            display: inline-flex;
            align-items: center;
            gap: 0.4rem;
            text-decoration: none;
            transition: all 0.2s;
        }

        .btn-print {
            background-color: #10b981;
            color: white;
        }

        .btn-print:hover {
            background-color: #059669;
        }

        .btn-back {
            background-color: rgba(255,255,255,0.1);
            color: white;
            border: 1px solid rgba(255,255,255,0.2);
        }

        .btn-back:hover {
            background-color: rgba(255,255,255,0.15);
        }

        /* AREA DOKUMEN SKL */
        .paper-container {
            max-width: 800px;
            margin: 2rem auto;
            background-color: white;
            padding: 3.5rem 4rem;
            box-shadow: 0 10px 25px rgba(0,0,0,0.05);
            border-radius: 8px;
            min-height: 297mm; /* Tinggi A4 mendekati */
        }

        /* Kop Surat (Header Resmi) */
        .kop-surat {
            display: flex;
            align-items: center;
            border-bottom: 4px double #000000;
            padding-bottom: 1.2rem;
            margin-bottom: 2rem;
        }

        .kop-logo {
            width: 85px;
            height: 85px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 3rem;
            color: #3b82f6;
            margin-right: 1.5rem;
            border: 2px solid #000;
            border-radius: 12px;
        }

        .kop-teks {
            flex: 1;
            text-align: center;
        }

        .kop-pemerintah {
            font-size: 1.1rem;
            font-weight: bold;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .kop-sekolah {
            font-size: 1.6rem;
            font-weight: 800;
            text-transform: uppercase;
            margin: 0.2rem 0;
            letter-spacing: 0.5px;
        }

        .kop-alamat {
            font-size: 0.9rem;
            font-style: italic;
        }

        /* Judul SKL */
        .doc-title {
            text-align: center;
            margin-bottom: 2rem;
        }

        .doc-title h2 {
            font-size: 1.4rem;
            font-weight: bold;
            text-decoration: underline;
            text-transform: uppercase;
        }

        .doc-title p {
            font-size: 1rem;
            margin-top: 0.3rem;
        }

        /* Isi SKL */
        .doc-body {
            font-size: 1.1rem;
            margin-bottom: 1.5rem;
            text-align: justify;
        }

        .doc-body p {
            margin-bottom: 1rem;
            text-indent: 30px;
        }

        /* Tabel Biodata Resmi */
        .bio-table {
            width: 90%;
            margin: 1.5rem auto;
            border-collapse: collapse;
        }

        .bio-table td {
            padding: 0.4rem 0.8rem;
            font-size: 1.1rem;
            vertical-align: top;
        }

        .bio-table td.label {
            width: 30%;
        }

        .bio-table td.separator {
            width: 3%;
        }

        .bio-table td.value {
            font-weight: bold;
        }

        /* Tabel Transkrip Nilai */
        .tbl-nilai {
            width: 100%;
            border-collapse: collapse;
            margin: 2rem 0;
        }

        .tbl-nilai th, .tbl-nilai td {
            border: 1px solid #000000;
            padding: 0.6rem 1rem;
            font-size: 1.05rem;
        }

        .tbl-nilai th {
            font-weight: bold;
            text-align: center;
            background-color: #f3f4f6;
        }

        .tbl-nilai td.center {
            text-align: center;
        }

        .tbl-nilai td.right {
            text-align: right;
            font-weight: bold;
        }

        .tbl-nilai tr.bold td {
            font-weight: bold;
            background-color: #f9fafb;
        }

        /* Tanda Tangan */
        .signature-block {
            display: flex;
            justify-content: flex-end;
            margin-top: 3.5rem;
            page-break-inside: avoid;
        }

        .signature-wrapper {
            width: 300px;
            text-align: left;
        }

        .signature-date {
            margin-bottom: 0.4rem;
        }

        .signature-title {
            margin-bottom: 5rem;
        }

        .signature-name {
            font-weight: bold;
            text-decoration: underline;
        }

        /* MEDIA CETAK (@media print) */
        @media print {
            body {
                background-color: white;
                color: black;
                padding-bottom: 0;
            }

            .print-nav {
                display: none; /* Sembunyikan navigasi di cetak */
            }

            .paper-container {
                margin: 0;
                padding: 0;
                box-shadow: none;
                border-radius: 0;
                width: 100%;
                min-height: auto;
            }

            /* Hapus margin atas/bawah browser default */
            @page {
                size: A4;
                margin: 2cm 2cm 2cm 2cm;
            }
        }
    </style>
</head>
<body>

    <!-- Floating Navigation Bar (Hanya di layar monitor) -->
    <div class="print-nav">
        <div class="print-nav-title">
            <i class="fa-solid fa-file-pdf"></i>
            <span>Pratinjau Cetak Surat Keterangan Kelulusan (SKL)</span>
        </div>
        <div class="print-nav-buttons">
            <a href="hasil.php" class="btn-nav btn-back">
                <i class="fa-solid fa-arrow-left"></i>
                <span>Kembali</span>
            </a>
            <button onclick="window.print();" class="btn-nav btn-print">
                <i class="fa-solid fa-print"></i>
                <span>Cetak / Simpan PDF</span>
            </button>
        </div>
    </div>

    <!-- AREA DOKUMEN CETAK KERTAS -->
    <div class="paper-container">
        
        <!-- KOP SURAT SEKOLAH -->
        <div class="kop-surat">
            <div class="kop-logo">
                <i class="fa-solid fa-graduation-cap" style="color: black;"></i>
            </div>
            <div class="kop-teks">
                <div class="kop-pemerintah">Pemerintah Kabupaten / Kota Administrasi</div>
                <div class="kop-sekolah"><?= htmlspecialchars($namaSekolah) ?></div>
                <div class="kop-alamat"><?= htmlspecialchars($alamatSekolah) ?></div>
            </div>
        </div>

        <!-- JUDUL SURAT -->
        <div class="doc-title">
            <h2>Surat Keterangan Kelulusan</h2>
            <p>Nomor: 421.2/SKL-06/<?= date('Y') ?></p>
        </div>

        <!-- ISI SURAT -->
        <div class="doc-body">
            <p>Yang bertanda tangan di bawah ini, Kepala Sekolah <strong><?= htmlspecialchars($namaSekolah) ?></strong> menerangkan bahwa siswa berikut ini:</p>
            
            <table class="bio-table">
                <tr>
                    <td class="label">Nama Lengkap</td>
                    <td class="separator">:</td>
                    <td class="value"><?= htmlspecialchars($student['nama']) ?></td>
                </tr>
                <tr>
                    <td class="label">Nomor Induk Siswa Nasional (NISN)</td>
                    <td class="separator">:</td>
                    <td class="value"><?= htmlspecialchars($student['nisn']) ?></td>
                </tr>
                <tr>
                    <td class="label">Nomor Peserta Ujian</td>
                    <td class="separator">:</td>
                    <td class="value"><?= htmlspecialchars($student['nomor_peserta']) ?></td>
                </tr>
                <tr>
                    <td class="label">Tempat, Tanggal Lahir</td>
                    <td class="separator">:</td>
                    <td class="value"><?= htmlspecialchars($student['tempat_lahir'] . ', ' . formatTanggalIndo($student['tanggal_lahir'])) ?></td>
                </tr>
            </table>

            <p style="margin-top: 1.5rem;">Berdasarkan hasil rapat pleno dewan pendidik dan kriteria kelulusan yang telah ditentukan oleh sekolah, siswa tersebut di atas dinyatakan:</p>
            
            <div style="text-align: center; margin: 1.5rem 0;">
                <span style="font-size: 1.8rem; font-weight: bold; border: 3px double #000; padding: 0.5rem 2.5rem; text-transform: uppercase;">
                    L U L U S
                </span>
            </div>

            <p>Dengan perolehan nilai hasil ujian sekolah sebagai berikut:</p>

            <!-- TABEL TRANSKRIP NILAI -->
            <table class="tbl-nilai">
                <thead>
                    <tr>
                        <th style="width: 10%;">No.</th>
                        <th style="width: 60%; text-align: left;">Mata Pelajaran</th>
                        <th style="width: 30%;">Nilai Ujian</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="center">1</td>
                        <td>Pendidikan Agama</td>
                        <td class="center"><?= number_format($student['nilai_agama'], 2) ?></td>
                    </tr>
                    <tr>
                        <td class="center">2</td>
                        <td>Pancasila & Kewarganegaraan (PPKn)</td>
                        <td class="center"><?= number_format($student['nilai_ppkn'], 2) ?></td>
                    </tr>
                    <tr>
                        <td class="center">3</td>
                        <td>Bahasa Indonesia</td>
                        <td class="center"><?= number_format($student['nilai_indonesia'], 2) ?></td>
                    </tr>
                    <tr>
                        <td class="center">4</td>
                        <td>Matematika</td>
                        <td class="center"><?= number_format($student['nilai_matematika'], 2) ?></td>
                    </tr>
                    <tr>
                        <td class="center">5</td>
                        <td>Ilmu Pengetahuan Alam (IPA)</td>
                        <td class="center"><?= number_format($student['nilai_ipa'], 2) ?></td>
                    </tr>
                    <tr>
                        <td class="center">6</td>
                        <td>Ilmu Pengetahuan Sosial (IPS)</td>
                        <td class="center"><?= number_format($student['nilai_ips'], 2) ?></td>
                    </tr>
                    <tr>
                        <td class="center">7</td>
                        <td>Seni Budaya & Prakarya (SBDP)</td>
                        <td class="center"><?= number_format($student['nilai_sbdp'], 2) ?></td>
                    </tr>
                    <tr>
                        <td class="center">8</td>
                        <td>Pendidikan Jasmani, Olahraga & Kesehatan</td>
                        <td class="center"><?= number_format($student['nilai_pjok'], 2) ?></td>
                    </tr>
                    <tr class="bold">
                        <td colspan="2" style="text-align: right; padding-right: 1.5rem;">Rata-Rata Nilai</td>
                        <td class="center"><?= number_format($student['nilai_rata_rata'], 2) ?></td>
                    </tr>
                </tbody>
            </table>

            <p style="margin-top: 1.5rem;">Surat keterangan ini diterbitkan sebagai informasi kelulusan sementara bagi siswa, sebelum Surat Tanda Tamat Belajar (Ijazah) resmi diterbitkan.</p>
        </div>

        <!-- BLOK TANDA TANGAN KEPALA SEKOLAH -->
        <div class="signature-block">
            <div class="signature-wrapper">
                <div class="signature-date">Jakarta, <?= formatTanggalIndo(date('Y-m-d')) ?></div>
                <div class="signature-title">Kepala Sekolah,</div>
                <div class="signature-name"><?= htmlspecialchars($namaKepsek) ?></div>
                <div>NIP. <?= htmlspecialchars($nipKepsek) ?></div>
            </div>
        </div>

    </div>

</body>
</html>
