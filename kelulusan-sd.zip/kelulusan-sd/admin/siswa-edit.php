<?php
// Mengimpor koneksi database
require_once __DIR__ . '/../config/database.php';

// Memastikan admin sudah login
require_once __DIR__ . '/header-admin.php';

$errorMsg = '';
$successMsg = '';
$student = null;

// Cek parameter ID siswa
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($id <= 0) {
    header('Location: siswa-list.php');
    exit;
}

// Mengambil data siswa saat ini
try {
    $stmt = $pdo->prepare("SELECT * FROM students WHERE id = :id");
    $stmt->execute(['id' => $id]);
    $student = $stmt->fetch();

    if (!$student) {
        $_SESSION['crud_error'] = 'Data siswa tidak ditemukan!';
        header('Location: siswa-list.php');
        exit;
    }
} catch (PDOException $e) {
    die("Gagal menghubungi database!");
}

// Proses pembaruan data siswa
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Biodata
    $nisn = trim($_POST['nisn'] ?? '');
    $nomorPeserta = trim($_POST['nomor_peserta'] ?? '');
    $nama = trim($_POST['nama'] ?? '');
    $tempatLahir = trim($_POST['tempat_lahir'] ?? '');
    $tanggalLahir = trim($_POST['tanggal_lahir'] ?? '');
    $statusKelulusan = $_POST['status_kelulusan'] ?? 'LULUS';
    
    // Nilai (Konversi ke Float/Decimal)
    $nilaiInd = floatval($_POST['nilai_indonesia'] ?? 0);
    $nilaiMat = floatval($_POST['nilai_matematika'] ?? 0);
    $nilaiIpa = floatval($_POST['nilai_ipa'] ?? 0);
    $nilaiIps = floatval($_POST['nilai_ips'] ?? 0);
    $nilaiPpkn = floatval($_POST['nilai_ppkn'] ?? 0);
    $nilaiAgama = floatval($_POST['nilai_agama'] ?? 0);
    $nilaiPjok = floatval($_POST['nilai_pjok'] ?? 0);
    $nilaiSbdp = floatval($_POST['nilai_sbdp'] ?? 0);

    // Validasi
    if (empty($nisn) || empty($nomorPeserta) || empty($nama) || empty($tempatLahir) || empty($tanggalLahir)) {
        $errorMsg = 'Seluruh data biodata wajib diisi dengan lengkap!';
    } elseif (strlen($nisn) !== 10 || !is_numeric($nisn)) {
        $errorMsg = 'NISN harus berisi tepat 10 digit angka!';
    } else {
        try {
            // Cek duplikasi NISN atau Nomor Peserta (Kecuali ID saat ini)
            $checkStmt = $pdo->prepare("SELECT COUNT(*) FROM students WHERE (nisn = :nisn OR nomor_peserta = :nomor_peserta) AND id != :id");
            $checkStmt->execute([
                'nisn' => $nisn,
                'nomor_peserta' => $nomorPeserta,
                'id' => $id
            ]);
            $count = $checkStmt->fetchColumn();

            if ($count > 0) {
                $errorMsg = 'Gagal! NISN atau Nomor Peserta Ujian sudah terdaftar di siswa lain.';
            } else {
                // Update ke database
                $sql = "UPDATE students SET 
                        nisn = :nisn, 
                        nomor_peserta = :nomor_peserta, 
                        nama = :nama, 
                        tempat_lahir = :tempat_lahir, 
                        tanggal_lahir = :tanggal_lahir, 
                        status_kelulusan = :status_kelulusan, 
                        nilai_indonesia = :nilai_indonesia, 
                        nilai_matematika = :nilai_matematika, 
                        nilai_ipa = :nilai_ipa, 
                        nilai_ips = :nilai_ips, 
                        nilai_ppkn = :nilai_ppkn, 
                        nilai_agama = :nilai_agama, 
                        nilai_pjok = :nilai_pjok, 
                        nilai_sbdp = :nilai_sbdp 
                        WHERE id = :id";
                
                $updateStmt = $pdo->prepare($sql);
                $updateStmt->execute([
                    'nisn' => $nisn,
                    'nomor_peserta' => $nomorPeserta,
                    'nama' => $nama,
                    'tempat_lahir' => $tempatLahir,
                    'tanggal_lahir' => $tanggalLahir,
                    'status_kelulusan' => $statusKelulusan,
                    'nilai_indonesia' => $nilaiInd,
                    'nilai_matematika' => $nilaiMat,
                    'nilai_ipa' => $nilaiIpa,
                    'nilai_ips' => $nilaiIps,
                    'nilai_ppkn' => $nilaiPpkn,
                    'nilai_agama' => $nilaiAgama,
                    'nilai_pjok' => $nilaiPjok,
                    'nilai_sbdp' => $nilaiSbdp,
                    'id' => $id
                ]);

                $_SESSION['crud_success'] = "Berhasil memperbarui data siswa " . htmlspecialchars($nama) . "!";
                echo "<script>window.location.href='siswa-list.php';</script>";
                exit;
            }
        } catch (PDOException $e) {
            $errorMsg = 'Kesalahan database saat menyimpan pembaruan: ' . $e->getMessage();
        }
    }
}
?>

        <!-- Tombol Kembali -->
        <div style="margin-bottom: 1.5rem;">
            <a href="siswa-list.php" class="btn-admin btn-secondary" style="font-size: 0.85rem; padding: 0.5rem 1rem;">
                <i class="fa-solid fa-arrow-left"></i>
                <span>Batal & Kembali</span>
            </a>
        </div>

        <?php if (!empty($errorMsg)): ?>
            <div class="admin-alert admin-alert-danger">
                <i class="fa-solid fa-triangle-exclamation"></i>
                <span><?= htmlspecialchars($errorMsg) ?></span>
            </div>
        <?php endif; ?>

        <!-- CARD FORM BOX -->
        <div class="card-box">
            <div class="card-box-header">
                <h3 class="card-box-title"><i class="fa-solid fa-user-pen" style="color: var(--primary-light); margin-right: 0.5rem;"></i> Edit Data Siswa: <?= htmlspecialchars($student['nama']) ?></h3>
            </div>

            <form action="siswa-edit.php?id=<?= $student['id'] ?>" method="POST">
                
                <!-- BAGIAN 1: BIODATA -->
                <h4 style="color: white; margin-bottom: 1rem; border-bottom: 1px solid var(--border-color); padding-bottom: 0.5rem; font-size: 1rem;">
                    <i class="fa-solid fa-address-card" style="color: var(--primary-light); margin-right: 0.4rem;"></i> Biodata Identitas Siswa
                </h4>
                
                <div class="admin-form-row admin-form-row-2">
                    <div class="admin-form-group">
                        <label class="admin-form-label" for="nama">Nama Lengkap Siswa</label>
                        <input class="admin-form-input" type="text" id="nama" name="nama" placeholder="Contoh: Andi Pratama" required autocomplete="off" value="<?= htmlspecialchars($student['nama']) ?>">
                    </div>
                    <div class="admin-form-group">
                        <label class="admin-form-label" for="status_kelulusan">Status Kelulusan</label>
                        <select class="admin-form-input" id="status_kelulusan" name="status_kelulusan" style="background-color: var(--bg-card); cursor: pointer;">
                            <option value="LULUS" <?= $student['status_kelulusan'] === 'LULUS' ? 'selected' : '' ?>>LULUS</option>
                            <option value="TIDAK LULUS" <?= $student['status_kelulusan'] === 'TIDAK LULUS' ? 'selected' : '' ?>>TIDAK LULUS</option>
                        </select>
                    </div>
                </div>

                <div class="admin-form-row admin-form-row-3">
                    <div class="admin-form-group">
                        <label class="admin-form-label" for="nisn">Nomor Induk Siswa Nasional (NISN)</label>
                        <input class="admin-form-input" type="text" id="nisn" name="nisn" placeholder="10 Digit NISN" required maxlength="10" pattern="\d{10}" autocomplete="off" value="<?= htmlspecialchars($student['nisn']) ?>">
                    </div>
                    <div class="admin-form-group">
                        <label class="admin-form-label" for="nomor_peserta">Nomor Peserta Ujian</label>
                        <input class="admin-form-input" type="text" id="nomor_peserta" name="nomor_peserta" placeholder="Contoh: 02-001-001-8" required autocomplete="off" value="<?= htmlspecialchars($student['nomor_peserta']) ?>">
                    </div>
                    <div class="admin-form-group">
                        <div class="admin-form-row admin-form-row-2" style="gap: 0.8rem;">
                            <div>
                                <label class="admin-form-label" for="tempat_lahir">Tempat Lahir</label>
                                <input class="admin-form-input" type="text" id="tempat_lahir" name="tempat_lahir" placeholder="Cth: Jakarta" required autocomplete="off" value="<?= htmlspecialchars($student['tempat_lahir']) ?>">
                            </div>
                            <div>
                                <label class="admin-form-label" for="tanggal_lahir">Tanggal Lahir</label>
                                <input class="admin-form-input" type="date" id="tanggal_lahir" name="tanggal_lahir" required value="<?= htmlspecialchars($student['tanggal_lahir']) ?>">
                            </div>
                        </div>
                    </div>
                </div>

                <!-- BAGIAN 2: NILAI -->
                <h4 style="color: white; margin-top: 1.5rem; margin-bottom: 1rem; border-bottom: 1px solid var(--border-color); padding-bottom: 0.5rem; font-size: 1rem;">
                    <i class="fa-solid fa-file-invoice" style="color: var(--success); margin-right: 0.4rem;"></i> Transkrip Nilai Ujian Sekolah (Skala 0 - 100)
                </h4>
                
                <div class="admin-form-row admin-form-row-4">
                    <div class="admin-form-group">
                        <label class="admin-form-label" for="nilai_agama">Pendidikan Agama</label>
                        <input class="admin-form-input" type="number" id="nilai_agama" name="nilai_agama" placeholder="0 - 100" min="0" max="100" step="0.01" value="<?= htmlspecialchars($student['nilai_agama']) ?>">
                    </div>
                    <div class="admin-form-group">
                        <label class="admin-form-label" for="nilai_ppkn">PPKn</label>
                        <input class="admin-form-input" type="number" id="nilai_ppkn" name="nilai_ppkn" placeholder="0 - 100" min="0" max="100" step="0.01" value="<?= htmlspecialchars($student['nilai_ppkn']) ?>">
                    </div>
                    <div class="admin-form-group">
                        <label class="admin-form-label" for="nilai_indonesia">Bahasa Indonesia</label>
                        <input class="admin-form-input" type="number" id="nilai_indonesia" name="nilai_indonesia" placeholder="0 - 100" min="0" max="100" step="0.01" value="<?= htmlspecialchars($student['nilai_indonesia']) ?>">
                    </div>
                    <div class="admin-form-group">
                        <label class="admin-form-label" for="nilai_matematika">Matematika</label>
                        <input class="admin-form-input" type="number" id="nilai_matematika" name="nilai_matematika" placeholder="0 - 100" min="0" max="100" step="0.01" value="<?= htmlspecialchars($student['nilai_matematika']) ?>">
                    </div>
                </div>

                <div class="admin-form-row admin-form-row-4">
                    <div class="admin-form-group">
                        <label class="admin-form-label" for="nilai_ipa">IPA</label>
                        <input class="admin-form-input" type="number" id="nilai_ipa" name="nilai_ipa" placeholder="0 - 100" min="0" max="100" step="0.01" value="<?= htmlspecialchars($student['nilai_ipa']) ?>">
                    </div>
                    <div class="admin-form-group">
                        <label class="admin-form-label" for="nilai_ips">IPS</label>
                        <input class="admin-form-input" type="number" id="nilai_ips" name="nilai_ips" placeholder="0 - 100" min="0" max="100" step="0.01" value="<?= htmlspecialchars($student['nilai_ips']) ?>">
                    </div>
                    <div class="admin-form-group">
                        <label class="admin-form-label" for="nilai_sbdp">Seni Budaya (SBDP)</label>
                        <input class="admin-form-input" type="number" id="nilai_sbdp" name="nilai_sbdp" placeholder="0 - 100" min="0" max="100" step="0.01" value="<?= htmlspecialchars($student['nilai_sbdp']) ?>">
                    </div>
                    <div class="admin-form-group">
                        <label class="admin-form-label" for="nilai_pjok">PJOK (Olahraga)</label>
                        <input class="admin-form-input" type="number" id="nilai_pjok" name="nilai_pjok" placeholder="0 - 100" min="0" max="100" step="0.01" value="<?= htmlspecialchars($student['nilai_pjok']) ?>">
                    </div>
                </div>

                <div class="form-actions">
                    <a href="siswa-list.php" class="btn-admin btn-secondary">
                        <i class="fa-solid fa-xmark"></i>
                        <span>Batalkan</span>
                    </a>
                    <button type="submit" class="btn-admin btn-primary">
                        <i class="fa-solid fa-floppy-disk"></i>
                        <span>Simpan Perubahan</span>
                    </button>
                </div>

            </form>
        </div>

    </div> <!-- Tutup main-content (dibuka di header-admin.php) -->
</div> <!-- Tutup admin-wrapper (dibuka di header-admin.php) -->

<!-- JS Admin -->
<script src="../assets/js/main.js"></script>
</body>
</html>
