<?php
// Mengimpor koneksi database
require_once __DIR__ . '/../config/database.php';

// Memastikan admin sudah login
require_once __DIR__ . '/header-admin.php';

// Inisialisasi variabel pencarian
$searchQuery = isset($_GET['q']) ? trim($_GET['q']) : '';
$students = [];

try {
    if (!empty($searchQuery)) {
        // Query dengan pencarian nama atau NISN
        $stmt = $pdo->prepare("SELECT * FROM students WHERE nama LIKE :q OR nisn LIKE :q OR nomor_peserta LIKE :q ORDER BY nama ASC");
        $stmt->execute(['q' => '%' . $searchQuery . '%']);
        $students = $stmt->fetchAll();
    } else {
        // Query seluruh data
        $stmt = $pdo->query("SELECT * FROM students ORDER BY nama ASC");
        $students = $stmt->fetchAll();
    }
} catch (PDOException $e) {
    echo "<div class='admin-alert admin-alert-danger'><i class='fa-solid fa-circle-exclamation'></i> Gagal memuat data siswa! " . htmlspecialchars($e->getMessage()) . "</div>";
}

$alertMsg = '';
$alertType = '';
if (isset($_SESSION['crud_success'])) {
    $alertMsg = $_SESSION['crud_success'];
    $alertType = 'success';
    unset($_SESSION['crud_success']);
} elseif (isset($_SESSION['crud_error'])) {
    $alertMsg = $_SESSION['crud_error'];
    $alertType = 'danger';
    unset($_SESSION['crud_error']);
}
?>

        <!-- ALERTS NOTIFIKASI -->
        <?php if (!empty($alertMsg)): ?>
            <div class="admin-alert admin-alert-<?= $alertType ?>">
                <i class="fa-solid <?= $alertType === 'success' ? 'fa-circle-check' : 'fa-triangle-exclamation' ?>"></i>
                <span><?= htmlspecialchars($alertMsg) ?></span>
            </div>
        <?php endif; ?>

        <!-- BOX UTAMA DATA SISWA -->
        <div class="card-box">
            <div class="card-box-header">
                <h3 class="card-box-title"><i class="fa-solid fa-graduation-cap" style="color: var(--primary-light); margin-right: 0.5rem;"></i> Daftar Siswa & Transkrip Nilai</h3>
                
                <div class="header-actions">
                    <!-- Form Pencarian -->
                    <form action="siswa-list.php" method="GET" class="search-box">
                        <input type="text" name="q" placeholder="Cari Nama, NISN..." value="<?= htmlspecialchars($searchQuery) ?>" autocomplete="off">
                        <i class="fa-solid fa-magnifying-glass"></i>
                    </form>
                    
                    <!-- Tombol Aksi Tambah -->
                    <a href="siswa-add.php" class="btn-admin btn-primary">
                        <i class="fa-solid fa-user-plus"></i>
                        <span>Tambah Siswa</span>
                    </a>
                    
                    <a href="siswa-import.php" class="btn-admin btn-success">
                        <i class="fa-solid fa-file-import"></i>
                        <span>Impor CSV</span>
                    </a>
                </div>
            </div>

            <!-- TABEL DATA -->
            <div class="table-responsive">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>NISN</th>
                            <th>No. Peserta</th>
                            <th>Nama Siswa</th>
                            <th>Tempat, Tgl Lahir</th>
                            <th style="text-align: center;">Rata-Rata</th>
                            <th style="text-align: center;">Status</th>
                            <th style="text-align: center; width: 100px;">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($students)): ?>
                            <tr>
                                <td colspan="7" style="text-align: center; color: var(--text-body); padding: 2rem;">
                                    <?php if (!empty($searchQuery)): ?>
                                        Tidak ditemukan hasil pencarian untuk "<strong><?= htmlspecialchars($searchQuery) ?></strong>". <a href="siswa-list.php" style="color: var(--primary-light);">Reset pencarian</a>.
                                    <?php else: ?>
                                        Belum ada data siswa di database. Silakan <a href="siswa-add.php" style="color: var(--primary-light);">tambah data siswa</a> secara manual atau lakukan impor CSV.
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($students as $std): ?>
                                <tr>
                                    <td style="font-weight: 600; font-variant-numeric: tabular-nums;"><?= htmlspecialchars($std['nisn']) ?></td>
                                    <td style="font-variant-numeric: tabular-nums;"><?= htmlspecialchars($std['nomor_peserta']) ?></td>
                                    <td style="font-weight: 600; color: white;"><?= htmlspecialchars($std['nama']) ?></td>
                                    <td><?= htmlspecialchars($std['tempat_lahir'] . ', ' . formatTanggalIndo($std['tanggal_lahir'])) ?></td>
                                    <td style="text-align: center; font-weight: bold; color: var(--primary-light);"><?= number_format($std['nilai_rata_rata'], 2) ?></td>
                                    <td style="text-align: center;">
                                        <span class="badge <?= $std['status_kelulusan'] === 'LULUS' ? 'badge-success' : 'badge-danger' ?>">
                                            <?= htmlspecialchars($std['status_kelulusan']) ?>
                                        </span>
                                    </td>
                                    <td style="text-align: center;">
                                        <div class="action-links" style="justify-content: center;">
                                            <!-- Edit -->
                                            <a href="siswa-edit.php?id=<?= $std['id'] ?>" class="action-btn btn-edit" title="Ubah Data Siswa & Nilai">
                                                <i class="fa-solid fa-pen-to-square"></i>
                                            </a>
                                            <!-- Hapus -->
                                            <a href="siswa-delete.php?id=<?= $std['id'] ?>" class="action-btn btn-delete" title="Hapus Siswa" onclick="return confirm('Apakah Anda yakin ingin menghapus data siswa <?= addslashes(htmlspecialchars($std['nama'])) ?> beserta seluruh nilainya? Tindakan ini tidak dapat dibatalkan.');">
                                                <i class="fa-solid fa-trash-can"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div> <!-- Tutup main-content (dibuka di header-admin.php) -->
</div> <!-- Tutup admin-wrapper (dibuka di header-admin.php) -->

<!-- JS Admin -->
<script src="../assets/js/main.js"></script>
</body>
</html>
