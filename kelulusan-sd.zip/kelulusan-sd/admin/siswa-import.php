<?php
// Mengimpor koneksi database
require_once __DIR__ . '/../config/database.php';

// Memastikan admin sudah login
require_once __DIR__ . '/header-admin.php';

$successMsg = '';
$errorMsg = '';
$importResults = [];

// Proses unggah & impor CSV
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['csv_file'])) {
    $file = $_FILES['csv_file'];

    if ($file['error'] !== UPLOAD_ERR_OK) {
        $errorMsg = 'Gagal mengunggah file! Pastikan ukuran file tidak melebihi batas upload.';
    } else {
        $fileExt = pathinfo($file['name'], PATHINFO_EXTENSION);
        if (strtolower($fileExt) !== 'csv') {
            $errorMsg = 'Format file salah! Harap unggah file dengan format .csv';
        } else {
            // Membuka file CSV
            if (($handle = fopen($file['tmp_name'], 'r')) !== false) {
                $rowCount = 0;
                $successCount = 0;
                $failedCount = 0;
                $errorsList = [];
                
                // Deteksi pembatas (delimiter) secara dinamis (koma atau titik koma)
                $firstLine = fgets($handle);
                $delimiter = ',';
                if (strpos($firstLine, ';') !== false) {
                    $delimiter = ';';
                }
                rewind($handle); // Kembalikan pointer pembacaan ke awal file
                
                // Mendapatkan baris pertama sebagai header
                $header = fgetcsv($handle, 1000, $delimiter);
                
                // Query SQL dengan ON DUPLICATE KEY UPDATE untuk fleksibilitas
                $sql = "INSERT INTO students 
                        (nisn, nomor_peserta, nama, tempat_lahir, tanggal_lahir, status_kelulusan, 
                         nilai_agama, nilai_ppkn, nilai_indonesia, nilai_matematika, nilai_ipa, nilai_ips, nilai_sbdp, nilai_pjok) 
                        VALUES 
                        (:nisn, :nomor_peserta, :nama, :tempat_lahir, :tanggal_lahir, :status_kelulusan, 
                         :nilai_agama, :nilai_ppkn, :nilai_indonesia, :nilai_matematika, :nilai_ipa, :nilai_ips, :nilai_sbdp, :nilai_pjok)
                        ON DUPLICATE KEY UPDATE
                        nomor_peserta = VALUES(nomor_peserta),
                        nama = VALUES(nama),
                        tempat_lahir = VALUES(tempat_lahir),
                        tanggal_lahir = VALUES(tanggal_lahir),
                        status_kelulusan = VALUES(status_kelulusan),
                        nilai_agama = VALUES(nilai_agama),
                        nilai_ppkn = VALUES(nilai_ppkn),
                        nilai_indonesia = VALUES(nilai_indonesia),
                        nilai_matematika = VALUES(nilai_matematika),
                        nilai_ipa = VALUES(nilai_ipa),
                        nilai_ips = VALUES(nilai_ips),
                        nilai_sbdp = VALUES(nilai_sbdp),
                        nilai_pjok = VALUES(nilai_pjok)";
                
                $stmt = $pdo->prepare($sql);

                while (($data = fgetcsv($handle, 1000, $delimiter)) !== false) {
                    $rowCount++;
                    
                    // Lewati baris kosong atau tidak lengkap
                    if (count($data) < 6) {
                        $failedCount++;
                        $errorsList[] = "Baris #{$rowCount}: Kolom biodata dasar tidak lengkap (Terbaca ".count($data)." kolom).";
                        continue;
                    }
                    
                    // Mapping data dari CSV
                    $nisn = trim($data[0]);
                    
                    // Keamanan: Bersihkan UTF-8 BOM jika file diekspor dari Microsoft Excel
                    $nisn = preg_replace('/[\x{FEFF}\x{FFFE}]/u', '', $nisn);
                    
                    $nomorPeserta = trim($data[1]);
                    $nama = trim($data[2]);
                    $tempatLahir = trim($data[3]);
                    $tanggalLahir = trim($data[4]); // format YYYY-MM-DD
                    
                    // Normalisasi tanggal jika menggunakan format Indonesia (DD-MM-YYYY atau DD/MM/YYYY)
                    $cleanDate = str_replace('/', '-', $tanggalLahir);
                    $timestamp = strtotime($cleanDate);
                    if ($timestamp !== false) {
                        // Jika format terbalik (misal 15-05-2014), strtotime memahaminya dan kita ubah ke YYYY-MM-DD
                        $tanggalLahir = date('Y-m-d', $timestamp);
                    }
                    
                    $statusKelulusan = strtoupper(trim($data[5])); // LULUS / TIDAK LULUS
                    
                    // Nilai (default 0 jika kosong)
                    $nilaiAgama = floatval($data[6] ?? 0);
                    $nilaiPpkn = floatval($data[7] ?? 0);
                    $nilaiInd = floatval($data[8] ?? 0);
                    $nilaiMat = floatval($data[9] ?? 0);
                    $nilaiIpa = floatval($data[10] ?? 0);
                    $nilaiIps = floatval($data[11] ?? 0);
                    $nilaiSbdp = floatval($data[12] ?? 0);
                    $nilaiPjok = floatval($data[13] ?? 0);

                    // Validasi Dasar
                    if (empty($nisn) || empty($nomorPeserta) || empty($nama) || empty($tempatLahir) || empty($tanggalLahir)) {
                        $failedCount++;
                        $errorsList[] = "Baris #{$rowCount} [NISN: {$nisn}]: Ada kolom biodata wajib yang kosong.";
                        continue;
                    }

                    if (strlen($nisn) !== 10 || !is_numeric($nisn)) {
                        $failedCount++;
                        $errorsList[] = "Baris #{$rowCount} [NISN: {$nisn}]: NISN harus bernilai angka tepat 10 digit.";
                        continue;
                    }

                    if ($statusKelulusan !== 'LULUS' && $statusKelulusan !== 'TIDAK LULUS') {
                        $statusKelulusan = 'LULUS'; // fallback
                    }

                    // Eksekusi Insert/Update
                    try {
                        $stmt->execute([
                            'nisn' => $nisn,
                            'nomor_peserta' => $nomorPeserta,
                            'nama' => $nama,
                            'tempat_lahir' => $tempatLahir,
                            'tanggal_lahir' => $tanggalLahir,
                            'status_kelulusan' => $statusKelulusan,
                            'nilai_agama' => $nilaiAgama,
                            'nilai_ppkn' => $nilaiPpkn,
                            'nilai_indonesia' => $nilaiInd,
                            'nilai_matematika' => $nilaiMat,
                            'nilai_ipa' => $nilaiIpa,
                            'nilai_ips' => $nilaiIps,
                            'nilai_sbdp' => $nilaiSbdp,
                            'nilai_pjok' => $nilaiPjok
                        ]);
                        $successCount++;
                    } catch (PDOException $e) {
                        $failedCount++;
                        $errorsList[] = "Baris #{$rowCount} [NISN: {$nisn}]: Gagal menyimpan ke database. Error: " . $e->getMessage();
                    }
                }
                
                fclose($handle);
                
                // Simpan hasil untuk ditampilkan
                $importResults = [
                    'total' => $rowCount,
                    'success' => $successCount,
                    'failed' => $failedCount,
                    'errors' => $errorsList
                ];
                
                if ($failedCount === 0) {
                    $successMsg = "Sukses mengimpor seluruh data! Total {$successCount} data berhasil dimasukkan/diperbarui.";
                } else {
                    $successMsg = "Proses impor selesai dengan beberapa catatan. {$successCount} sukses, {$failedCount} gagal.";
                }
            } else {
                $errorMsg = 'Gagal membaca isi file CSV!';
            }
        }
    }
}
?>

        <!-- Tombol Kembali -->
        <div style="margin-bottom: 1.5rem;">
            <a href="siswa-list.php" class="btn-admin btn-secondary" style="font-size: 0.85rem; padding: 0.5rem 1rem;">
                <i class="fa-solid fa-arrow-left"></i>
                <span>Kembali ke Daftar</span>
            </a>
        </div>

        <!-- NOTIFIKASI HASIL -->
        <?php if (!empty($successMsg)): ?>
            <div class="admin-alert admin-alert-success">
                <i class="fa-solid fa-circle-check"></i>
                <span><?= htmlspecialchars($successMsg) ?></span>
            </div>
        <?php endif; ?>

        <?php if (!empty($errorMsg)): ?>
            <div class="admin-alert admin-alert-danger">
                <i class="fa-solid fa-triangle-exclamation"></i>
                <span><?= htmlspecialchars($errorMsg) ?></span>
            </div>
        <?php endif; ?>

        <div style="display: grid; grid-template-columns: 1fr; gap: 1.5rem;">
            
            <!-- FORM IMPORT BOX -->
            <div class="card-box">
                <div class="card-box-header">
                    <h3 class="card-box-title"><i class="fa-solid fa-file-csv" style="color: var(--success); margin-right: 0.5rem;"></i> Unggah & Impor File CSV</h3>
                </div>
                
                <form action="siswa-import.php" method="POST" enctype="multipart/form-data">
                    <div class="admin-form-group">
                        <label class="admin-form-label" for="csv_file">Pilih File CSV (.csv)</label>
                        <input class="admin-form-input" type="file" id="csv_file" name="csv_file" accept=".csv" required style="padding: 0.5rem;">
                        <small style="color: var(--text-body); font-size: 0.75rem; margin-top: 0.5rem; display: block;">Pastikan format file dipisahkan dengan koma (comma delimited).</small>
                    </div>

                    <div style="margin-top: 1.5rem;">
                        <button type="submit" class="btn-admin btn-success">
                            <i class="fa-solid fa-upload"></i>
                            <span>Mulai Impor Data</span>
                        </button>
                    </div>
                </form>
            </div>

            <!-- DETAIL LAPORAN KESALAHAN JIKA ADA -->
            <?php if (!empty($importResults) && !empty($importResults['errors'])): ?>
                <div class="card-box" style="border-color: rgba(239, 68, 68, 0.2);">
                    <div class="card-box-header">
                        <h3 class="card-box-title" style="color: var(--danger-light);"><i class="fa-solid fa-triangle-exclamation"></i> Daftar Catatan Kesalahan Impor</h3>
                    </div>
                    <div style="max-height: 250px; overflow-y: auto; background-color: rgba(0,0,0,0.2); padding: 1rem; border-radius: 10px;">
                        <ul style="list-style-type: none; font-size: 0.85rem; display: flex; flex-direction: column; gap: 0.5rem;">
                            <?php foreach ($importResults['errors'] as $err): ?>
                                <li style="color: #fca5a5; border-bottom: 1px solid rgba(255,255,255,0.03); padding-bottom: 0.3rem;"><i class="fa-solid fa-xmark" style="margin-right: 0.4rem;"></i> <?= htmlspecialchars($err) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>
            <?php endif; ?>

            <!-- DOKUMENTASI FORMAT CSV -->
            <div class="card-box">
                <div class="card-box-header">
                    <h3 class="card-box-title"><i class="fa-solid fa-circle-question" style="color: var(--primary-light); margin-right: 0.5rem;"></i> Petunjuk Format File CSV</h3>
                </div>
                
                <div style="font-size: 0.9rem; line-height: 1.6; display: flex; flex-direction: column; gap: 1rem;">
                    <p>Format file CSV harus memiliki header di baris pertama dan dipisahkan dengan tanda koma (,). Berikut adalah struktur kolom dan urutan datanya:</p>
                    
                    <div style="background-color: rgba(0,0,0,0.3); padding: 1rem; border-radius: 10px; font-family: monospace; font-size: 0.8rem; overflow-x: auto; color: white;">
                        nisn,nomor_peserta,nama,tempat_lahir,tanggal_lahir,status_kelulusan,nilai_agama,nilai_ppkn,nilai_indonesia,nilai_matematika,nilai_ipa,nilai_ips,nilai_sbdp,nilai_pjok<br>
                        0123456701,02-001-010-1,Rudi Hermawan,Jakarta,2014-05-15,LULUS,85.00,90.00,88.50,75.00,80.00,82.00,85.00,90.00<br>
                        0123456702,02-001-010-2,Susi Susanti,Bandung,2014-09-20,LULUS,90.00,95.00,92.00,88.00,89.50,91.00,90.00,95.00
                    </div>

                    <div style="margin-top: 0.5rem;">
                        <h5 style="color: white; font-size: 0.95rem; margin-bottom: 0.5rem; font-weight: 700;">Ketentuan Data Kolom:</h5>
                        <ul style="padding-left: 1.2rem; display: flex; flex-direction: column; gap: 0.4rem; font-size: 0.85rem;">
                            <li><strong>nisn</strong>: 10 digit angka unik siswa (kunci utama, jika sudah terdaftar maka data akan <strong>diperbarui / update</strong> otomatis).</li>
                            <li><strong>nomor_peserta</strong>: Nomor ujian resmi siswa (cth: 02-001-010-1).</li>
                            <li><strong>nama</strong>: Nama lengkap siswa.</li>
                            <li><strong>tempat_lahir</strong>: Kota kelahiran siswa.</li>
                            <li><strong>tanggal_lahir</strong>: Tanggal lahir siswa dengan format internasional: <strong>YYYY-MM-DD</strong> (Tahun-Bulan-Hari, contoh: 2014-05-15).</li>
                            <li><strong>status_kelulusan</strong>: Bernilai <strong>LULUS</strong> atau <strong>TIDAK LULUS</strong>.</li>
                            <li><strong>nilai_*</strong>: Kolom nilai ke-7 sampai ke-14 harus berupa angka desimal/bulat berskala <strong>0 sampai 100</strong> (contoh: 88.50 atau 75).</li>
                        </ul>
                    </div>
                </div>
            </div>

        </div>

    </div> <!-- Tutup main-content (dibuka di header-admin.php) -->
</div> <!-- Tutup admin-wrapper (dibuka di header-admin.php) -->

<!-- JS Admin -->
<script src="../assets/js/main.js"></script>
</body>
</html>
