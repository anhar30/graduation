/**
 * Canvas Confetti - Efek Perayaan Kelulusan Mandiri
 * Tanpa ketergantungan pustaka eksternal (CDN), berfungsi offline secara penuh.
 */

class ConfettiEngine {
    constructor(canvasId) {
        this.canvas = document.getElementById(canvasId);
        if (!this.canvas) return;
        
        this.ctx = this.canvas.getContext('2d');
        this.particles = [];
        this.colors = [
            '#6366f1', '#818cf8', '#4f46e5', // Indigos
            '#10b981', '#34d399',            // Greens
            '#f59e0b', '#fbbf24',            // Golds
            '#ec4899', '#f472b6',            // Pinks
            '#3b82f6', '#60a5fa'             // Blues
        ];
        
        this.resizeCanvas();
        window.addEventListener('resize', () => this.resizeCanvas());
    }
    
    resizeCanvas() {
        this.canvas.width = window.innerWidth;
        this.canvas.height = window.innerHeight;
    }
    
    createParticle() {
        const x = Math.random() * this.canvas.width;
        const y = Math.random() * -50 - 20; // Mulai di atas layar
        const size = Math.random() * 8 + 6;
        const color = this.colors[Math.floor(Math.random() * this.colors.length)];
        
        return {
            x: x,
            y: y,
            size: size,
            color: color,
            speedX: Math.random() * 4 - 2,
            speedY: Math.random() * 4 + 4,
            rotation: Math.random() * 360,
            rotationSpeed: Math.random() * 4 - 2,
            shape: Math.random() > 0.5 ? 'circle' : 'square'
        };
    }
    
    start(durationMs = 6000) {
        if (!this.canvas) return;
        
        // Spawn partikel awal
        for (let i = 0; i < 150; i++) {
            this.particles.push(this.createParticle());
            // Acak posisi Y agar partikel tersebar di layar saat pertama kali muncul
            this.particles[i].y = Math.random() * this.canvas.height * 0.8;
        }
        
        const spawnInterval = setInterval(() => {
            if (this.particles.length < 250) {
                this.particles.push(this.createParticle());
            }
        }, 80);
        
        // Hentikan penambahan partikel setelah waktu habis
        setTimeout(() => {
            clearInterval(spawnInterval);
        }, durationMs);
        
        this.animate();
    }
    
    animate() {
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        
        for (let i = 0; i < this.particles.length; i++) {
            const p = this.particles[i];
            
            p.y += p.speedY;
            p.x += p.speedX;
            p.rotation += p.rotationSpeed;
            
            this.ctx.save();
            this.ctx.translate(p.x + p.size / 2, p.y + p.size / 2);
            this.ctx.rotate((p.rotation * Math.PI) / 180);
            this.ctx.fillStyle = p.color;
            
            if (p.shape === 'circle') {
                this.ctx.beginPath();
                this.ctx.arc(0, 0, p.size / 2, 0, Math.PI * 2);
                this.ctx.fill();
            } else {
                this.ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size);
            }
            
            this.ctx.restore();
            
            // Regenerasi partikel jika keluar dari bawah layar
            if (p.y > this.canvas.height) {
                // Hanya hidupkan kembali jika partikel masih dibutuhkan (tidak dihapus secara bertahap)
                this.particles[i] = this.createParticle();
            }
        }
        
        requestAnimationFrame(() => this.animate());
    }
}

// Inisialisasi otomatis jika terdapat kanvas confetti di halaman
document.addEventListener('DOMContentLoaded', () => {
    if (document.getElementById('confetti-canvas')) {
        const confetti = new ConfettiEngine('confetti-canvas');
        confetti.start(8000); // Berjalan selama 8 detik
    }
});
