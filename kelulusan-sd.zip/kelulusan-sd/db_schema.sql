-- Skema Database Kelulusan SD Kelas 6 Modern
-- Simpan file ini dan impor ke MySQL Server Anda (misal: phpMyAdmin)

CREATE DATABASE IF NOT EXISTS `kelulusan_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `kelulusan_db`;

-- 1. TABEL PENGATURAN APLIKASI
CREATE TABLE IF NOT EXISTS `settings` (
    `key` VARCHAR(50) NOT NULL PRIMARY KEY,
    `value` TEXT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert default settings
INSERT INTO `settings` (`key`, `value`) VALUES
('nama_sekolah', 'SD Negeri Cerdas Bangsa'),
('tahun_ajaran', '2025/2026'),
('tanggal_pengumuman', '2026-06-15 10:00:00'),
('nama_kepsek', 'Drs. Budi Santoso, M.Pd.'),
('nip_kepsek', '19750812 200003 1 002'),
('alamat_sekolah', 'Jl. Pendidikan No. 45, Jakarta Pusat'),
('logo_sekolah', '')
ON DUPLICATE KEY UPDATE `value` = VALUES(`value`);

-- 2. TABEL PENGGUNA (ADMIN)
CREATE TABLE IF NOT EXISTS `users` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `username` VARCHAR(50) NOT NULL UNIQUE,
    `password` VARCHAR(255) NOT NULL,
    `nama_lengkap` VARCHAR(100) NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert default admin user
-- Username: admin
-- Password: admin123 (Sudah di-hash menggunakan password_hash() PHP / bcrypt)
INSERT INTO `users` (`username`, `password`, `nama_lengkap`) VALUES
('admin', '$2y$10$QQ/ouQGUeEdff2tfK92tuepxVO/6262I8GKxRQCn7RbvCK3wDggXS', 'Administrator Sekolah')
ON DUPLICATE KEY UPDATE `username` = `username`;

-- 3. TABEL SISWA & NILAI
CREATE TABLE IF NOT EXISTS `students` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `nisn` VARCHAR(10) NOT NULL UNIQUE,
    `nomor_peserta` VARCHAR(20) NOT NULL UNIQUE,
    `nama` VARCHAR(150) NOT NULL,
    `tempat_lahir` VARCHAR(100) NOT NULL,
    `tanggal_lahir` DATE NOT NULL,
    `status_kelulusan` ENUM('LULUS', 'TIDAK LULUS') NOT NULL DEFAULT 'LULUS',
    
    -- Nilai Mata Pelajaran
    `nilai_indonesia` DECIMAL(5,2) DEFAULT 0.00,
    `nilai_matematika` DECIMAL(5,2) DEFAULT 0.00,
    `nilai_ipa` DECIMAL(5,2) DEFAULT 0.00,
    `nilai_ips` DECIMAL(5,2) DEFAULT 0.00,
    `nilai_ppkn` DECIMAL(5,2) DEFAULT 0.00,
    `nilai_agama` DECIMAL(5,2) DEFAULT 0.00,
    `nilai_pjok` DECIMAL(5,2) DEFAULT 0.00,
    `nilai_sbdp` DECIMAL(5,2) DEFAULT 0.00,
    `nilai_rata_rata` DECIMAL(5,2) GENERATED ALWAYS AS (
        (`nilai_indonesia` + `nilai_matematika` + `nilai_ipa` + `nilai_ips` + `nilai_ppkn` + `nilai_agama` + `nilai_pjok` + `nilai_sbdp`) / 8
    ) STORED,
    
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Contoh Data Siswa untuk pengujian awal
-- Password login siswa: NISN & Tanggal Lahir (Format: YYYY-MM-DD, cth: 2014-04-12)
INSERT INTO `students` 
(`nisn`, `nomor_peserta`, `nama`, `tempat_lahir`, `tanggal_lahir`, `status_kelulusan`, `nilai_indonesia`, `nilai_matematika`, `nilai_ipa`, `nilai_ips`, `nilai_ppkn`, `nilai_agama`, `nilai_pjok`, `nilai_sbdp`) 
VALUES
('0123456789', '02-001-001-8', 'Andi Pratama', 'Jakarta', '2014-04-12', 'LULUS', 88.50, 92.00, 85.50, 80.00, 90.00, 95.00, 87.00, 86.00),
('0123456788', '02-001-002-9', 'Siti Rahmawati', 'Bandung', '2014-08-25', 'LULUS', 94.00, 86.50, 91.00, 88.00, 95.00, 92.00, 85.00, 90.00),
('0123456787', '02-001-003-2', 'Rian Hidayat', 'Surabaya', '2013-11-05', 'TIDAK LULUS', 50.00, 45.00, 55.00, 60.00, 58.00, 65.00, 70.00, 62.00)
ON DUPLICATE KEY UPDATE `nisn` = `nisn`;
