<?php
// Mengimpor koneksi database
require_once __DIR__ . '/../config/database.php';

// Memastikan admin sudah login (ditangani di header-admin.php, tapi panggil session di database.php)
require_once __DIR__ . '/header-admin.php';

// Inisialisasi variabel statistik default
$totalSiswa = 0;
$totalLulus = 0;
$totalTidakLulus = 0;
$rataRataKelas = 0.00;
$topStudents = [];

try {
    // 1. Total Siswa
    $totalSiswa = $pdo->query("SELECT COUNT(*) FROM students")->fetchColumn();

    if ($totalSiswa > 0) {
        // 2. Total Lulus
        $totalLulus = $pdo->query("SELECT COUNT(*) FROM students WHERE status_kelulusan = 'LULUS'")->fetchColumn();

        // 3. Total Tidak Lulus
        $totalTidakLulus = $pdo->query("SELECT COUNT(*) FROM students WHERE status_kelulusan = 'TIDAK LULUS'")->fetchColumn();

        // 4. Rata-Rata Nilai Seluruh Kelas
        $rataRataKelas = $pdo->query("SELECT AVG(nilai_rata_rata) FROM students")->fetchColumn();

        // 5. 5 Siswa dengan Nilai Tertinggi
        $stmtTop = $pdo->query("SELECT nama, nisn, nilai_rata_rata, status_kelulusan FROM students ORDER BY nilai_rata_rata DESC LIMIT 5");
        $topStudents = $stmtTop->fetchAll();
    }
} catch (PDOException $e) {
    echo "<div class='admin-alert admin-alert-danger'><i class='fa-solid fa-circle-exclamation'></i> Gagal memuat statistik database! " . htmlspecialchars($e->getMessage()) . "</div>";
}

// Mendapatkan konfigurasi pengumuman saat ini
$settings = getAllSettings();
$tanggalPengumuman = $settings['tanggal_pengumuman'] ?? '2026-06-15 10:00:00';
$currentTime = time();
$releaseTime = strtotime($tanggalPengumuman);
$isReleased = $currentTime >= $releaseTime;
?>

        <!-- GRID KARTU STATISTIK (METRICS) -->
        <div class="metrics-grid">
            
            <!-- TOTAL SISWA -->
            <div class="metric-card">
                <div class="metric-info">
                    <span class="metric-label">Total Siswa</span>
                    <span class="metric-value"><?= $totalSiswa ?></span>
                </div>
                <div class="metric-icon icon-primary">
                    <i class="fa-solid fa-users"></i>
                </div>
            </div>

            <!-- TOTAL LULUS -->
            <div class="metric-card">
                <div class="metric-info">
                    <span class="metric-label">Siswa Lulus</span>
                    <span class="metric-value"><?= $totalLulus ?></span>
                </div>
                <div class="metric-icon icon-success">
                    <i class="fa-solid fa-user-check"></i>
                </div>
            </div>

            <!-- TOTAL TIDAK LULUS -->
            <div class="metric-card">
                <div class="metric-info">
                    <span class="metric-label">Tidak Lulus</span>
                    <span class="metric-value"><?= $totalTidakLulus ?></span>
                </div>
                <div class="metric-icon icon-danger">
                    <i class="fa-solid fa-user-xmark"></i>
                </div>
            </div>

            <!-- RATA-RATA NILAI -->
            <div class="metric-card">
                <div class="metric-info">
                    <span class="metric-label">Rata-Rata Ujian</span>
                    <span class="metric-value"><?= number_format($rataRataKelas, 2) ?></span>
                </div>
                <div class="metric-icon icon-warning">
                    <i class="fa-solid fa-chart-line"></i>
                </div>
            </div>

        </div>

        <div style="display: grid; grid-template-columns: 1fr; gap: 1.5rem; margin-bottom: 2rem;">
            <!-- STATS BOX 1: STATUS APLIKASI -->
            <div class="card-box">
                <div class="card-box-header">
                    <h3 class="card-box-title"><i class="fa-solid fa-circle-info" style="color: var(--primary-light); margin-right: 0.5rem;"></i> Status Pengumuman Saat Ini</h3>
                </div>
                <div style="display: flex; flex-direction: column; gap: 1rem;">
                    <div style="display: flex; justify-content: space-between; padding-bottom: 0.8rem; border-bottom: 1px solid var(--border-color);">
                        <span>Status Rilis Portal Siswa:</span>
                        <div>
                            <?php if ($isReleased): ?>
                                <span class="badge badge-success"><i class="fa-solid fa-lock-open"></i> SUDAH RILIS (BUKA)</span>
                            <?php else: ?>
                                <span class="badge badge-danger" style="background-color: rgba(245, 158, 11, 0.1); color: var(--warning); border: 1px solid rgba(245, 158, 11, 0.2);"><i class="fa-solid fa-lock"></i> BELUM RILIS (HITUNG MUNDUR)</span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div style="display: flex; justify-content: space-between; padding-bottom: 0.8rem; border-bottom: 1px solid var(--border-color);">
                        <span>Waktu Rilis Pengumuman:</span>
                        <span style="font-weight: 600; color: white;"><?= formatDateTimeIndo($tanggalPengumuman) ?></span>
                    </div>
                    <div style="display: flex; justify-content: space-between;">
                        <span>Nama Sekolah:</span>
                        <span style="font-weight: 600; color: white;"><?= htmlspecialchars($settings['nama_sekolah'] ?? 'SD Negeri Cerdas Bangsa') ?></span>
                    </div>
                </div>
            </div>
        </div>

        <!-- STATS BOX 2: TOP 5 SISWA -->
        <div class="card-box">
            <div class="card-box-header">
                <h3 class="card-box-title"><i class="fa-solid fa-award" style="color: var(--warning); margin-right: 0.5rem;"></i> 5 Siswa dengan Nilai Tertinggi</h3>
                <a href="siswa-list.php" class="btn-admin btn-secondary" style="font-size: 0.8rem; padding: 0.4rem 0.8rem;">
                    <span>Lihat Semua Siswa</span>
                    <i class="fa-solid fa-arrow-right"></i>
                </a>
            </div>

            <div class="table-responsive">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Peringkat</th>
                            <th>NISN</th>
                            <th>Nama Siswa</th>
                            <th style="text-align: center;">Status</th>
                            <th style="text-align: right;">Rata-Rata Nilai</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($topStudents)): ?>
                            <tr>
                                <td colspan="5" style="text-align: center; color: var(--text-body);">Belum ada data siswa di database. Silakan <a href="siswa-add.php" style="color: var(--primary-light);">tambah data</a> atau <a href="siswa-import.php" style="color: var(--primary-light);">impor CSV</a>.</td>
                            </tr>
                        <?php else: ?>
                            <?php $rank = 1; foreach ($topStudents as $std): ?>
                                <tr>
                                    <td style="font-weight: bold; width: 10%; color: var(--primary-light);"><?= $rank++ ?></td>
                                    <td><?= htmlspecialchars($std['nisn']) ?></td>
                                    <td style="font-weight: 600; color: white;"><?= htmlspecialchars($std['nama']) ?></td>
                                    <td style="text-align: center;">
                                        <span class="badge <?= $std['status_kelulusan'] === 'LULUS' ? 'badge-success' : 'badge-danger' ?>">
                                            <?= htmlspecialchars($std['status_kelulusan']) ?>
                                        </span>
                                    </td>
                                    <td style="text-align: right; font-weight: bold; color: var(--warning);"><?= number_format($std['nilai_rata_rata'], 2) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div> <!-- Tutup main-content (dibuka di header-admin.php) -->
</div> <!-- Tutup admin-wrapper (dibuka di header-admin.php) -->

<!-- JS Admin -->
<script src="../assets/js/main.js"></script>
</body>
</html>
