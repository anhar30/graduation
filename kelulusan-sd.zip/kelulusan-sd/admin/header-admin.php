<?php
// Enforce admin login check
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

// Mendapatkan halaman aktif saat ini
$currentPage = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Sistem Kelulusan</title>
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Admin CSS -->
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>

<div class="admin-wrapper">
    
    <!-- SIDEBAR -->
    <aside class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">
                <i class="fa-solid fa-user-shield"></i>
            </div>
            <div class="sidebar-title">
                ADMIN PANEL
                <span>Kelulusan SD</span>
            </div>
        </div>
        
        <ul class="sidebar-menu">
            <li class="sidebar-item <?= $currentPage === 'index.php' ? 'active' : '' ?>">
                <a href="index.php">
                    <i class="fa-solid fa-chart-pie"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="sidebar-item <?= in_array($currentPage, ['siswa-list.php', 'siswa-add.php', 'siswa-edit.php']) ? 'active' : '' ?>">
                <a href="siswa-list.php">
                    <i class="fa-solid fa-users-gear"></i>
                    <span>Data Siswa & Nilai</span>
                </a>
            </li>
            <li class="sidebar-item <?= $currentPage === 'siswa-import.php' ? 'active' : '' ?>">
                <a href="siswa-import.php">
                    <i class="fa-solid fa-file-import"></i>
                    <span>Impor CSV Siswa</span>
                </a>
            </li>
            <li class="sidebar-item <?= $currentPage === 'settings.php' ? 'active' : '' ?>">
                <a href="settings.php">
                    <i class="fa-solid fa-gears"></i>
                    <span>Pengaturan Aplikasi</span>
                </a>
            </li>
            <li class="sidebar-item" style="margin-top: 2rem; border-top: 1px solid var(--border-color); padding-top: 1.5rem;">
                <a href="../index.php" target="_blank">
                    <i class="fa-solid fa-earth-southeast"></i>
                    <span>Lihat Portal Siswa</span>
                </a>
            </li>
            <li class="sidebar-item" style="margin-top: auto;">
                <a href="logout.php" style="color: var(--danger-light);">
                    <i class="fa-solid fa-right-from-bracket"></i>
                    <span>Keluar (Logout)</span>
                </a>
            </li>
        </ul>
        
        <div class="sidebar-footer">
            <p>&copy; <?= date('Y') ?> Admin Panel SD</p>
        </div>
    </aside>
    
    <!-- MAIN CONTENT WRAPPER -->
    <div class="main-content">
        
        <!-- TOP NAVIGATION BAR -->
        <div class="topbar">
            <!-- Mobile Sidebar Toggle -->
            <a href="#" id="sidebar-toggle" style="color: white; font-size: 1.5rem; text-decoration: none; display: none;" class="mobile-toggle">
                <i class="fa-solid fa-bars"></i>
            </a>
            <style>
                @media (max-width: 991px) {
                    .mobile-toggle {
                        display: block !important;
                        margin-right: 1.5rem;
                    }
                }
            </style>
            
            <div class="topbar-left">
                <div class="page-title">
                    <?php
                    if ($currentPage === 'index.php') {
                        echo 'Ringkasan Dashboard';
                    } elseif (in_array($currentPage, ['siswa-list.php', 'siswa-add.php', 'siswa-edit.php'])) {
                        echo 'Manajemen Siswa';
                    } elseif ($currentPage === 'siswa-import.php') {
                        echo 'Impor Data Siswa';
                    } elseif ($currentPage === 'settings.php') {
                        echo 'Pengaturan Sistem';
                    } else {
                        echo 'Panel Kontrol';
                    }
                    ?>
                </div>
                <div class="page-subtitle">Selamat datang kembali di panel administrasi kelulusan.</div>
            </div>
            
            <div class="topbar-right">
                <div class="admin-profile">
                    <div class="admin-info">
                        <span class="admin-name"><?= htmlspecialchars($_SESSION['admin_name']) ?></span>
                        <span class="admin-role">Administrator Utama</span>
                    </div>
                    <div class="avatar">
                        <i class="fa-solid fa-user-shield"></i>
                    </div>
                </div>
            </div>
        </div>
