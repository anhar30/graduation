<?php
// Mengimpor koneksi database
require_once __DIR__ . '/../config/database.php';

// Jika admin sudah login, langsung alihkan ke dashboard
if (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
    header('Location: index.php');
    exit;
}

$errorMsg = '';

// Proses form login admin
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if (empty($username) || empty($password)) {
        $errorMsg = 'Username dan Password harus diisi!';
    } else {
        try {
            // Mencari user admin berdasarkan username
            $stmt = $pdo->prepare("SELECT * FROM users WHERE username = :username");
            $stmt->execute(['username' => $username]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password'])) {
                // Login sukses, simpan data ke session
                $_SESSION['admin_logged_in'] = true;
                $_SESSION['admin_id'] = $user['id'];
                $_SESSION['admin_username'] = $user['username'];
                $_SESSION['admin_name'] = $user['nama_lengkap'];

                header('Location: index.php');
                exit;
            } else {
                $errorMsg = 'Username atau Password salah!';
            }
        } catch (PDOException $e) {
            $errorMsg = 'Terjadi kesalahan database. Silakan hubungi pengembang.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Administrator - Pengumuman Kelulusan</title>
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Menggunakan CSS siswa untuk login glassmorphic yang cantik -->
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        body {
            background-image: 
                radial-gradient(at 0% 0%, rgba(79, 70, 229, 0.15) 0px, transparent 50%),
                radial-gradient(at 100% 100%, rgba(220, 38, 38, 0.08) 0px, transparent 50%);
        }
        .admin-badge {
            background: linear-gradient(135deg, var(--accent-danger), var(--primary-dark)) !important;
            box-shadow: 0 10px 25px rgba(239, 68, 68, 0.3) !important;
        }
    </style>
</head>
<body class="admin-login-body">

    <div class="container">
        
        <!-- HEADER -->
        <header>
            <div class="school-badge admin-badge">
                <i class="fa-solid fa-user-shield"></i>
            </div>
            <h1 class="school-title">Panel Administrator</h1>
            <p class="school-subtitle" style="color: var(--accent-danger);">Sistem Pengumuman Kelulusan</p>
        </header>

        <!-- FORM LOGIN -->
        <main>
            <div class="glass-card">
                <h2 class="form-title" style="margin-bottom: 1.5rem;">Masuk Admin</h2>

                <?php if (!empty($errorMsg)): ?>
                    <div class="alert alert-danger">
                        <i class="fa-solid fa-triangle-exclamation"></i>
                        <span><?= htmlspecialchars($errorMsg) ?></span>
                    </div>
                <?php endif; ?>

                <form action="login.php" method="POST">
                    <div class="form-group">
                        <label class="form-label" for="username">Username</label>
                        <div class="input-container">
                            <input class="form-input" type="text" id="username" name="username" placeholder="Masukkan username" required autocomplete="off">
                            <i class="fa-solid fa-user"></i>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="password">Password</label>
                        <div class="input-container">
                            <input class="form-input" type="password" id="password" name="password" placeholder="Masukkan password" required>
                            <i class="fa-solid fa-lock"></i>
                        </div>
                    </div>

                    <button type="submit" class="btn" style="background: linear-gradient(135deg, var(--accent-danger), var(--primary-dark)); box-shadow: 0 5px 15px rgba(239, 68, 68, 0.2);">
                        <span>Masuk Dashboard</span>
                        <i class="fa-solid fa-right-to-bracket"></i>
                    </button>
                </form>
                
                <div style="text-align: center; margin-top: 1.5rem;">
                    <a href="../index.php" style="color: var(--text-muted); text-decoration: none; font-size: 0.85rem; font-weight: 600; transition: var(--transition);" onmouseover="this.style.color='var(--text-white)'" onmouseout="this.style.color='var(--text-muted)'">
                        <i class="fa-solid fa-arrow-left" style="margin-right: 0.4rem;"></i> Halaman Portal Siswa
                    </a>
                </div>
            </div>
        </main>

        <!-- FOOTER -->
        <footer>
            <p>&copy; <?= date('Y') ?> Admin Kelulusan SD. All Rights Reserved.</p>
        </footer>

    </div>

</body>
</html>
