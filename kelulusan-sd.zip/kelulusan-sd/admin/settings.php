<?php
// Mengimpor koneksi database
require_once __DIR__ . '/../config/database.php';

// Memastikan admin sudah login
require_once __DIR__ . '/header-admin.php';

$successMsg = '';
$errorMsg = '';

// Proses penyimpanan pengaturan baru
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $postSettings = [
        'nama_sekolah' => trim($_POST['nama_sekolah'] ?? ''),
        'tahun_ajaran' => trim($_POST['tahun_ajaran'] ?? ''),
        'alamat_sekolah' => trim($_POST['alamat_sekolah'] ?? ''),
        'nama_kepsek' => trim($_POST['nama_kepsek'] ?? ''),
        'nip_kepsek' => trim($_POST['nip_kepsek'] ?? ''),
        'tanggal_pengumuman' => trim($_POST['tanggal_pengumuman'] ?? '')
    ];

    // Validasi
    if (empty($postSettings['nama_sekolah']) || empty($postSettings['tahun_ajaran']) || empty($postSettings['tanggal_pengumuman'])) {
        $errorMsg = 'Nama Sekolah, Tahun Ajaran, dan Tanggal Pengumuman wajib diisi!';
    } else {
        try {
            // Mengkonversi format input datetime-local browser (YYYY-MM-DDTHH:MM) ke format MySQL (YYYY-MM-DD HH:MM:SS)
            $formattedDate = str_replace('T', ' ', $postSettings['tanggal_pengumuman']);
            if (strlen($formattedDate) === 16) {
                $formattedDate .= ':00'; // Tambahkan detik default jika tidak ada
            }
            $postSettings['tanggal_pengumuman'] = $formattedDate;

            // Memulai transaksi SQL untuk keamanan
            $pdo->beginTransaction();
            
            $stmt = $pdo->prepare("INSERT INTO settings (`key`, `value`) VALUES (:key, :value) ON DUPLICATE KEY UPDATE `value` = :value");
            
            foreach ($postSettings as $key => $value) {
                $stmt->execute([
                    'key' => $key,
                    'value' => $value
                ]);
            }
            
            $pdo->commit();
            $successMsg = 'Seluruh pengaturan sistem berhasil disimpan dan diperbarui!';
        } catch (PDOException $e) {
            $pdo->rollBack();
            $errorMsg = 'Kesalahan database saat menyimpan pengaturan: ' . $e->getMessage();
        }
    }
}

// Mengambil seluruh pengaturan terbaru dari database
$settings = getAllSettings();

// Format tanggal pengumuman untuk input HTML datetime-local (ganti spasi dengan T)
$tanggalPengumumanDB = $settings['tanggal_pengumuman'] ?? '2026-06-15 10:00:00';
$tanggalPengumumanHTML = str_replace(' ', 'T', substr($tanggalPengumumanDB, 0, 16));
?>

        <!-- NOTIFIKASI -->
        <?php if (!empty($successMsg)): ?>
            <div class="admin-alert admin-alert-success">
                <i class="fa-solid fa-circle-check"></i>
                <span><?= htmlspecialchars($successMsg) ?></span>
            </div>
        <?php endif; ?>

        <?php if (!empty($errorMsg)): ?>
            <div class="admin-alert admin-alert-danger">
                <i class="fa-solid fa-triangle-exclamation"></i>
                <span><?= htmlspecialchars($errorMsg) ?></span>
            </div>
        <?php endif; ?>

        <!-- CARD SETTINGS BOX -->
        <div class="card-box">
            <div class="card-box-header">
                <h3 class="card-box-title"><i class="fa-solid fa-gears" style="color: var(--primary-light); margin-right: 0.5rem;"></i> Pengaturan Aplikasi & Kelulusan</h3>
            </div>

            <form action="settings.php" method="POST">
                
                <!-- BAGIAN 1: IDENTITAS SEKOLAH -->
                <h4 style="color: white; margin-bottom: 1rem; border-bottom: 1px solid var(--border-color); padding-bottom: 0.5rem; font-size: 1rem;">
                    <i class="fa-solid fa-school" style="color: var(--primary-light); margin-right: 0.4rem;"></i> Identitas Sekolah Dasar
                </h4>
                
                <div class="admin-form-row admin-form-row-2">
                    <div class="admin-form-group">
                        <label class="admin-form-label" for="nama_sekolah">Nama Resmi Sekolah</label>
                        <input class="admin-form-input" type="text" id="nama_sekolah" name="nama_sekolah" required autocomplete="off" value="<?= htmlspecialchars($settings['nama_sekolah'] ?? 'SD Negeri Cerdas Bangsa') ?>">
                    </div>
                    <div class="admin-form-group">
                        <label class="admin-form-label" for="tahun_ajaran">Tahun Ajaran</label>
                        <input class="admin-form-input" type="text" id="tahun_ajaran" name="tahun_ajaran" required placeholder="Contoh: 2025/2026" autocomplete="off" value="<?= htmlspecialchars($settings['tahun_ajaran'] ?? '2025/2026') ?>">
                    </div>
                </div>

                <div class="admin-form-group">
                    <label class="admin-form-label" for="alamat_sekolah">Alamat Lengkap Sekolah</label>
                    <input class="admin-form-input" type="text" id="alamat_sekolah" name="alamat_sekolah" autocomplete="off" value="<?= htmlspecialchars($settings['alamat_sekolah'] ?? 'Jl. Pendidikan No. 45, Jakarta Pusat') ?>">
                    <small style="color: var(--text-body); font-size: 0.75rem; display: block; margin-top: 0.3rem;">Alamat ini akan dicetak pada lembar Kop Surat SKL resmi.</small>
                </div>

                <!-- BAGIAN 2: KEPALA SEKOLAH & TANDA TANGAN -->
                <h4 style="color: white; margin-top: 1.5rem; margin-bottom: 1rem; border-bottom: 1px solid var(--border-color); padding-bottom: 0.5rem; font-size: 1rem;">
                    <i class="fa-solid fa-signature" style="color: var(--warning); margin-right: 0.4rem;"></i> Kepala Sekolah & Pejabat Penandatangan
                </h4>
                
                <div class="admin-form-row admin-form-row-2">
                    <div class="admin-form-group">
                        <label class="admin-form-label" for="nama_kepsek">Nama Lengkap Kepala Sekolah</label>
                        <input class="admin-form-input" type="text" id="nama_kepsek" name="nama_kepsek" placeholder="Lengkap dengan gelar akademik" autocomplete="off" value="<?= htmlspecialchars($settings['nama_kepsek'] ?? 'Drs. Budi Santoso, M.Pd.') ?>">
                    </div>
                    <div class="admin-form-group">
                        <label class="admin-form-label" for="nip_kepsek">Nomor Induk Pegawai (NIP)</label>
                        <input class="admin-form-input" type="text" id="nip_kepsek" name="nip_kepsek" placeholder="Masukkan 18 digit NIP" autocomplete="off" value="<?= htmlspecialchars($settings['nip_kepsek'] ?? '19750812 200003 1 002') ?>">
                    </div>
                </div>

                <!-- BAGIAN 3: WAKTU RILIS PENGUMUMAN -->
                <h4 style="color: white; margin-top: 1.5rem; margin-bottom: 1rem; border-bottom: 1px solid var(--border-color); padding-bottom: 0.5rem; font-size: 1rem;">
                    <i class="fa-solid fa-calendar-days" style="color: var(--success); margin-right: 0.4rem;"></i> Waktu Rilis Pengumuman Kelulusan
                </h4>
                
                <div class="admin-form-row admin-form-row-2">
                    <div class="admin-form-group">
                        <label class="admin-form-label" for="tanggal_pengumuman">Tanggal & Jam Pengumuman Dibuka</label>
                        <input class="admin-form-input" type="datetime-local" id="tanggal_pengumuman" name="tanggal_pengumuman" required value="<?= $tanggalPengumumanHTML ?>" style="color-scheme: dark; cursor: pointer;">
                        <small style="color: var(--text-body); font-size: 0.75rem; display: block; margin-top: 0.5rem;">Sebelum tanggal dan waktu ini terlampaui, halaman beranda siswa hanya akan menampilkan countdown timer dan menyembunyikan form masuk.</small>
                    </div>
                    <div style="display: flex; align-items: center; padding-left: 0.5rem;">
                        <div class="admin-alert admin-alert-success" style="margin-bottom: 0; background-color: rgba(99, 102, 241, 0.08); border-color: rgba(99, 102, 241, 0.15); color: var(--primary-light); width: 100%;">
                            <i class="fa-solid fa-circle-question"></i>
                            <span>Waktu server saat ini adalah: <strong><?= date('Y-m-d H:i') ?> WIB</strong>. Pastikan waktu rilis sudah sesuai dengan zona waktu server Anda.</span>
                        </div>
                    </div>
                </div>

                <div class="form-actions" style="margin-top: 2rem;">
                    <button type="submit" class="btn-admin btn-primary">
                        <i class="fa-solid fa-floppy-disk"></i>
                        <span>Simpan Seluruh Setelan</span>
                    </button>
                </div>

            </form>
        </div>

    </div> <!-- Tutup main-content (dibuka di header-admin.php) -->
</div> <!-- Tutup admin-wrapper (dibuka di header-admin.php) -->

<!-- JS Admin -->
<script src="../assets/js/main.js"></script>
</body>
</html>
