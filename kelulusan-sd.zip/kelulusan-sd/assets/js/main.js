/**
 * Script Utama - Aplikasi Pengumuman Kelulusan SD Modern
 * Menangani countdown timer pengumuman kelulusan & interaksi antarmuka portal.
 */

document.addEventListener('DOMContentLoaded', () => {
    initCountdown();
    setupMobileSidebar();
});

/**
 * Inisialisasi Hitung Mundur Pengumuman
 */
function initCountdown() {
    const timerContainer = document.getElementById('countdown-timer');
    if (!timerContainer) return;

    // Mendapatkan tanggal target rilis pengumuman dari atribut data
    const targetDateStr = timerContainer.getAttribute('data-target');
    if (!targetDateStr) return;

    // Format targetDateStr: "YYYY-MM-DD HH:MM:SS"
    // Konversi ke format ISO yang didukung oleh semua browser (ganti spasi dengan 'T')
    const formattedTargetStr = targetDateStr.replace(' ', 'T');
    const targetDate = new Date(formattedTargetStr);

    if (isNaN(targetDate.getTime())) {
        console.error('Format tanggal pengumuman tidak valid:', targetDateStr);
        return;
    }

    const daysEl = document.getElementById('days');
    const hoursEl = document.getElementById('hours');
    const minutesEl = document.getElementById('minutes');
    const secondsEl = document.getElementById('seconds');

    function updateTimer() {
        const now = new Date();
        const difference = targetDate - now;

        // Jika waktu pengumuman sudah tiba/lewat
        if (difference <= 0) {
            clearInterval(timerInterval);
            // Segarkan halaman untuk memunculkan form login
            window.location.reload();
            return;
        }

        // Kalkulasi Hari, Jam, Menit, dan Detik
        const days = Math.floor(difference / (1000 * 60 * 60 * 24));
        const hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((difference % (1000 * 60)) / 1000);

        // Menampilkan hasil kalkulasi dengan padding 0 di depan
        if (daysEl) daysEl.textContent = String(days).padStart(2, '0');
        if (hoursEl) hoursEl.textContent = String(hours).padStart(2, '0');
        if (minutesEl) minutesEl.textContent = String(minutes).padStart(2, '0');
        if (secondsEl) secondsEl.textContent = String(seconds).padStart(2, '0');
    }

    // Jalankan pertama kali
    updateTimer();
    // Perbarui setiap 1 detik
    const timerInterval = setInterval(updateTimer, 1000);
}

/**
 * Menangani Toggle Sidebar untuk Tampilan Admin Mobile
 */
function setupMobileSidebar() {
    const sidebarToggle = document.getElementById('sidebar-toggle');
    if (!sidebarToggle) return;

    sidebarToggle.addEventListener('click', (e) => {
        e.preventDefault();
        document.body.classList.toggle('sidebar-open');
    });

    // Menutup sidebar saat mengklik area main-content ketika sidebar sedang terbuka
    const mainContent = document.querySelector('.main-content');
    if (mainContent) {
        mainContent.addEventListener('click', () => {
            if (document.body.classList.contains('sidebar-open')) {
                document.body.classList.remove('sidebar-open');
            }
        });
    }
}
