<?php
// Konfigurasi Database MySQL
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', ''); // Sesuaikan dengan password database Anda (biasanya kosong di XAMPP/Laragon)
define('DB_NAME', 'kelulusan_db');

try {
    // Membuat koneksi PDO dengan charset UTF-8
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    // Jika koneksi gagal, tampilkan pesan ramah tetapi informatif
    die("Koneksi database gagal! Harap pastikan MySQL server Anda aktif dan database 'kelulusan_db' sudah diimpor. <br>Error: " . $e->getMessage());
}

/**
 * Mendapatkan nilai pengaturan berdasarkan key
 */
function getSetting($key, $default = '') {
    global $pdo;
    try {
        $stmt = $pdo->prepare("SELECT `value` FROM settings WHERE `key` = :key");
        $stmt->execute(['key' => $key]);
        $row = $stmt->fetch();
        return $row ? $row['value'] : $default;
    } catch (PDOException $e) {
        return $default;
    }
}

/**
 * Mendapatkan semua pengaturan
 */
function getAllSettings() {
    global $pdo;
    $settings = [];
    try {
        $stmt = $pdo->query("SELECT `key`, `value` FROM settings");
        while ($row = $stmt->fetch()) {
            $settings[$row['key']] = $row['value'];
        }
    } catch (PDOException $e) {
        // Terapkan default jika tabel belum siap
        $settings = [
            'nama_sekolah' => 'SD Negeri Cerdas Bangsa',
            'tahun_ajaran' => '2025/2026',
            'tanggal_pengumuman' => '2026-06-15 10:00:00',
            'nama_kepsek' => 'Drs. Budi Santoso, M.Pd.',
            'nip_kepsek' => '19750812 200003 1 002',
            'alamat_sekolah' => 'Jl. Pendidikan No. 45, Jakarta Pusat'
        ];
    }
    return $settings;
}

/**
 * Format tanggal YYYY-MM-DD menjadi "DD Bulan YYYY" (Bahasa Indonesia)
 */
function formatTanggalIndo($dateStr) {
    if (!$dateStr) return '';
    $timestamp = strtotime($dateStr);
    if (!$timestamp) return $dateStr;

    $hari = date('d', $timestamp);
    $bulan_num = date('m', $timestamp);
    $tahun = date('Y', $timestamp);

    $daftar_bulan = [
        '01' => 'Januari',
        '02' => 'Februari',
        '03' => 'Maret',
        '04' => 'April',
        '05' => 'Mei',
        '06' => 'Juni',
        '07' => 'Juli',
        '08' => 'Agustus',
        '09' => 'September',
        '10' => 'Oktobers', // singular typo fix: Oktober
        '11' => 'November',
        '12' => 'Desember'
    ];
    // Perbaikan typo untuk Oktober
    $daftar_bulan['10'] = 'Oktober';

    return $hari . ' ' . $daftar_bulan[$bulan_num] . ' ' . $tahun;
}

/**
 * Format tanggal dan waktu menjadi "DD Bulan YYYY jam HH:MM WIB"
 */
function formatDateTimeIndo($dateTimeStr) {
    if (!$dateTimeStr) return '';
    $timestamp = strtotime($dateTimeStr);
    if (!$timestamp) return $dateTimeStr;

    $tglStr = formatTanggalIndo(date('Y-m-d', $timestamp));
    $jamStr = date('H:i', $timestamp);

    return $tglStr . ' pukul ' . $jamStr . ' WIB';
}

// Inisialisasi Session jika belum dimulai
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
