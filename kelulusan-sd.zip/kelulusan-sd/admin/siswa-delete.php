<?php
// Mengimpor koneksi database
require_once __DIR__ . '/../config/database.php';

// Memastikan admin sudah login
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

// Proses Hapus Siswa
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id > 0) {
    try {
        // Ambil nama siswa sebelum dihapus untuk kepentingan log/pesan
        $nameStmt = $pdo->prepare("SELECT nama FROM students WHERE id = :id");
        $nameStmt->execute(['id' => $id]);
        $namaSiswa = $nameStmt->fetchColumn();

        if ($namaSiswa) {
            // Hapus data
            $deleteStmt = $pdo->prepare("DELETE FROM students WHERE id = :id");
            $deleteStmt->execute(['id' => $id]);

            $_SESSION['crud_success'] = "Berhasil menghapus data siswa " . htmlspecialchars($namaSiswa) . "!";
        } else {
            $_SESSION['crud_error'] = "Data siswa tidak ditemukan atau sudah dihapus!";
        }
    } catch (PDOException $e) {
        $_SESSION['crud_error'] = "Gagal menghapus siswa: " . $e->getMessage();
    }
} else {
    $_SESSION['crud_error'] = "ID siswa tidak valid!";
}

// Alihkan kembali ke daftar siswa
header('Location: siswa-list.php');
exit;
