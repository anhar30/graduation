<?php
// Script Pemulihan Password Admin Otomatis
// Jalankan script ini dengan mengakses: http://localhost/kelulusan-sd/admin/reset-admin.php

require_once __DIR__ . '/../config/database.php';

try {
    // Hash resmi untuk password "admin123"
    $newHash = '$2y$10$QQ/ouQGUeEdff2tfK92tuepxVO/6262I8GKxRQCn7RbvCK3wDggXS';
    
    // Perbarui password di database
    $stmt = $pdo->prepare("UPDATE users SET password = :password WHERE username = 'admin'");
    $stmt->execute(['password' => $newHash]);
    
    echo "<div style='font-family: Arial, sans-serif; max-width: 500px; margin: 50px auto; padding: 20px; border: 1px solid #10b981; background-color: #ecfdf5; border-radius: 8px; color: #065f46; text-align: center;'>";
    echo "<h2 style='margin-bottom: 10px;'>Sukses Merestart Password!</h2>";
    echo "<p>Password admin Anda berhasil diatur ulang menjadi: <strong>admin123</strong></p>";
    echo "<p style='margin-top: 20px;'><a href='login.php' style='display: inline-block; background-color: #10b981; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; font-weight: bold;'>Masuk ke Halaman Login</a></p>";
    echo "<small style='display: block; margin-top: 15px; color: #047857;'>Catatan: Demi keamanan, berkas pemulihan ini akan otomatis dihapus sekarang.</small>";
    echo "</div>";
    
    // Keamanan: Hapus berkas ini sendiri setelah sukses dieksekusi!
    unlink(__FILE__);
    
} catch (PDOException $e) {
    echo "<div style='font-family: Arial, sans-serif; max-width: 500px; margin: 50px auto; padding: 20px; border: 1px solid #ef4444; background-color: #fef2f2; border-radius: 8px; color: #991b1b; text-align: center;'>";
    echo "<h2>Gagal Mengatur Ulang Password!</h2>";
    echo "<p>Koneksi database gagal atau tabel 'users' belum ada. Pastikan XAMPP MySQL aktif dan database sudah diimpor.</p>";
    echo "<p style='font-size: 0.85rem; margin-top: 10px;'>Error: " . htmlspecialchars($e->getMessage()) . "</p>";
    echo "</div>";
}
