<?php
require_once __DIR__ . '/../config/database.php';

// Menghapus data session admin
if (isset($_SESSION['admin_logged_in'])) {
    unset($_SESSION['admin_logged_in']);
    unset($_SESSION['admin_id']);
    unset($_SESSION['admin_username']);
    unset($_SESSION['admin_name']);
}

// Hancurkan seluruh session
session_destroy();

// Alihkan ke login admin
header('Location: login.php');
exit;
