<?php
// Mengimpor koneksi database dan helper
require_once __DIR__ . '/config/database.php';

// Mendapatkan seluruh pengaturan dari database
$settings = getAllSettings();
$namaSekolah = $settings['nama_sekolah'] ?? 'SD Negeri Kamal 07 Pagi';
$tahunAjaran = $settings['tahun_ajaran'] ?? '2025/2026';
$tanggalPengumuman = $settings['tanggal_pengumuman'] ?? '2026-06-15 10:00:00';

// Menentukan apakah waktu pengumuman sudah tiba
$currentTime = time();
$releaseTime = strtotime($tanggalPengumuman);
$isReleased = $currentTime >= $releaseTime;

$errorMsg = '';
if (isset($_SESSION['login_error'])) {
    $errorMsg = $_SESSION['login_error'];
    unset($_SESSION['login_error']); // Hapus setelah dibaca
}

// Proses Login / Pencarian Kelulusan Siswa
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Keamanan tambahan: cegah pengiriman form jika belum waktunya rilis
    if (!$isReleased) {
        $errorMsg = 'Maaf, waktu pengumuman resmi belum dibuka!';
    } else {
        $nisn = trim($_POST['nisn'] ?? '');
        $tanggalLahir = trim($_POST['tanggal_lahir'] ?? '');

        if (empty($nisn) || empty($tanggalLahir)) {
            $errorMsg = 'Harap isi NISN dan Tanggal Lahir dengan lengkap!';
        } else {
            try {
                // Mencari siswa di database dengan prepared statement
                $stmt = $pdo->prepare("SELECT * FROM students WHERE nisn = :nisn AND tanggal_lahir = :tanggal_lahir");
                $stmt->execute([
                    'nisn' => $nisn,
                    'tanggal_lahir' => $tanggalLahir
                ]);
                $student = $stmt->fetch();

                if ($student) {
                    // Berhasil masuk, simpan data siswa ke session
                    $_SESSION['student_id'] = $student['id'];
                    header('Location: hasil.php');
                    exit;
                } else {
                    $errorMsg = 'Kombinasi NISN dan Tanggal Lahir tidak ditemukan. Silakan periksa kembali data Anda!';
                }
            } catch (PDOException $e) {
                $errorMsg = 'Terjadi kesalahan sistem. Silakan coba lagi beberapa saat lagi.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portal Pengumuman Kelulusan Kelas 6 - <?= htmlspecialchars($namaSekolah) ?></title>
    <!-- Favicon / Icon -->
    <link rel="icon" type="image/png" href="assets/images/favicon.png" onerror="this.style.display='none'">
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- CSS Utama -->
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

    <div class="container">
        
        <!-- HEADER / IDENTITAS SEKOLAH -->
        <header>
            <div class="school-badge">
                <i class="fa-solid fa-graduation-cap"></i>
            </div>
            <h1 class="school-title"><?= htmlspecialchars($namaSekolah) ?></h1>
            <p class="school-subtitle">Pengumuman Kelulusan Kelas 6</p>
            <p class="academic-year">Tahun Ajaran <?= htmlspecialchars($tahunAjaran) ?></p>
        </header>

        <!-- KONTEN PORTAL -->
        <main>
            
            <?php if (!$isReleased): ?>
                <!-- TAMPILAN COUNTDOWN (JIKA BELUM RILIS) -->
                <div class="glass-card countdown-container" id="countdown-card">
                    <h2 class="countdown-title">Menuju Pengumuman Resmi Kelulusan</h2>
                    
                    <!-- Timer Hitung Mundur -->
                    <div class="timer" id="countdown-timer" data-target="<?= htmlspecialchars($tanggalPengumuman) ?>">
                        <div class="timer-box">
                            <span class="timer-num" id="days">00</span>
                            <span class="timer-label">Hari</span>
                        </div>
                        <div class="timer-box">
                            <span class="timer-num" id="hours">00</span>
                            <span class="timer-label">Jam</span>
                        </div>
                        <div class="timer-box">
                            <span class="timer-num" id="minutes">00</span>
                            <span class="timer-label">Menit</span>
                        </div>
                        <div class="timer-box">
                            <span class="timer-num" id="seconds">00</span>
                            <span class="timer-label">Detik</span>
                        </div>
                    </div>

                    <div class="release-date-info">
                        <i class="fa-solid fa-calendar-check"></i>
                        <span>Rilis pada: <?= formatDateTimeIndo($tanggalPengumuman) ?></span>
                    </div>
                </div>
            <?php else: ?>
                <!-- TAMPILAN FORM LOGIN PORTAL SISWA (JIKA SUDAH RILIS) -->
                <div class="glass-card" id="login-card">
                    <h2 class="form-title">Cek Kelulusan Siswa</h2>

                    <?php if (!empty($errorMsg)): ?>
                        <div class="alert alert-danger">
                            <i class="fa-solid fa-triangle-exclamation"></i>
                            <span><?= htmlspecialchars($errorMsg) ?></span>
                        </div>
                    <?php endif; ?>

                    <form action="index.php" method="POST">
                        <div class="form-group">
                            <label class="form-label" for="nisn">Nomor Induk Siswa Nasional (NISN)</label>
                            <div class="input-container">
                                <input class="form-input" type="text" id="nisn" name="nisn" placeholder="Contoh: 0123456789" required autocomplete="off" maxlength="10" pattern="\d{10}">
                                <i class="fa-solid fa-id-card"></i>
                            </div>
                            <small style="color: var(--text-muted); font-size: 0.75rem; margin-top: 0.3rem; display: block;">Masukkan 10 digit NISN resmi Anda.</small>
                        </div>

                        <div class="form-group">
                            <label class="form-label" for="tanggal_lahir">Tanggal Lahir Siswa</label>
                            <div class="input-container">
                                <input class="form-input" type="date" id="tanggal_lahir" name="tanggal_lahir" required>
                                <i class="fa-solid fa-calendar-days"></i>
                            </div>
                        </div>

                        <button type="submit" class="btn">
                            <span>Periksa Hasil</span>
                            <i class="fa-solid fa-arrow-right"></i>
                        </button>
                    </form>
                </div>
            <?php endif; ?>

        </main>

        <!-- FOOTER -->
        <footer>
            <p>&copy; <?= date('Y') ?> <?= htmlspecialchars($namaSekolah) ?>. Semua Hak Dilindungi.</p>
            <p style="font-size: 0.75rem; margin-top: 0.3rem; color: rgba(255,255,255,0.25);">Developed with ❤️ SUAMI BU AYU</p>
        </footer>

    </div>

    <!-- JS Utama -->
    <script src="assets/js/main.js"></script>
</body>
</html>
