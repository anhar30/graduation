<?php
require_once __DIR__ . '/config/database.php';

// Keamanan: Cek apakah siswa sudah login
if (!isset($_SESSION['student_id'])) {
    $_SESSION['login_error'] = 'Silakan masukkan NISN dan Tanggal Lahir terlebih dahulu!';
    header('Location: index.php');
    exit;
}

// Mendapatkan data siswa berdasarkan ID di Session
try {
    $stmt = $pdo->prepare("SELECT * FROM students WHERE id = :id");
    $stmt->execute(['id' => $_SESSION['student_id']]);
    $student = $stmt->fetch();
    
    if (!$student) {
        // Jika data hilang atau terhapus
        session_destroy();
        header('Location: index.php');
        exit;
    }
} catch (PDOException $e) {
    die("Kesalahan sistem dalam memuat data siswa!");
}

// Mendapatkan seluruh pengaturan
$settings = getAllSettings();
$namaSekolah = $settings['nama_sekolah'] ?? 'SD Negeri Cerdas Bangsa';
$tahunAjaran = $settings['tahun_ajaran'] ?? '2025/2026';
$tanggalPengumuman = $settings['tanggal_pengumuman'] ?? '2026-06-15 10:00:00';

// Keamanan Tambahan: Cek apakah waktu rilis dilewati secara ilegal
$currentTime = time();
$releaseTime = strtotime($tanggalPengumuman);
if ($currentTime < $releaseTime) {
    // Sesi dihapus karena melanggar waktu rilis
    session_destroy();
    header('Location: index.php');
    exit;
}

// Handler logout / kembali ke halaman pencarian
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    unset($_SESSION['student_id']);
    header('Location: index.php');
    exit;
}

$status = $student['status_kelulusan'];
$isLulus = $status === 'LULUS';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hasil Kelulusan - <?= htmlspecialchars($student['nama']) ?></title>
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- CSS Utama -->
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

    <!-- KANVAS CONFETTI UNTUK SISWA YANG LULUS -->
    <?php if ($isLulus): ?>
        <canvas id="confetti-canvas"></canvas>
    <?php endif; ?>

    <div class="container" style="justify-content: flex-start; padding-top: 3rem;">
        
        <!-- HEADER PORTAL -->
        <header>
            <div class="school-badge">
                <i class="fa-solid fa-graduation-cap"></i>
            </div>
            <h1 class="school-title"><?= htmlspecialchars($namaSekolah) ?></h1>
            <p class="school-subtitle">Pengumuman Kelulusan Kelas 6</p>
            <p class="academic-year">Tahun Ajaran <?= htmlspecialchars($tahunAjaran) ?></p>
        </header>

        <!-- KONTEN PENGUMUMAN -->
        <main class="results-container">
            
            <div class="glass-card" style="max-width: 100%; text-align: center; margin-bottom: 2rem;">
                <!-- BADGE STATUS KELULUSAN -->
                <div class="badge-status <?= $isLulus ? 'status-lulus' : 'status-tidak-lulus' ?>">
                    <?= $isLulus ? '<i class="fa-solid fa-circle-check"></i> LULUS' : '<i class="fa-solid fa-circle-xmark"></i> TIDAK LULUS' ?>
                </div>

                <?php if ($isLulus): ?>
                    <h2 class="congrats-text">Selamat, <?= htmlspecialchars($student['nama']) ?>!</h2>
                    <p class="congrats-subtext">Anda dinyatakan LULUS dari jenjang Sekolah Dasar. Terus berprestasi di tingkat selanjutnya!</p>
                <?php else: ?>
                    <h2 class="congrats-text">Tetap Semangat, <?= htmlspecialchars($student['nama']) ?>!</h2>
                    <p class="congrats-subtext">Jangan berkecil hati. Perjalanan menuntut ilmu masih sangat panjang, tetap semangat belajar!</p>
                <?php endif; ?>

                <div class="results-grid">
                    
                    <!-- KARTU PROFIL BIODATA -->
                    <div class="student-bio">
                        <h3 class="score-title" style="margin-bottom: 1.5rem; justify-content: center; font-size: 1.05rem;">
                            <i class="fa-solid fa-address-card" style="margin-right: 0.5rem; color: var(--primary-light);"></i> Biodata Siswa
                        </h3>
                        
                        <div class="bio-item">
                            <div class="bio-label">Nama Siswa</div>
                            <div class="bio-val"><?= htmlspecialchars($student['nama']) ?></div>
                        </div>
                        <div class="bio-item">
                            <div class="bio-label">NISN</div>
                            <div class="bio-val"><?= htmlspecialchars($student['nisn']) ?></div>
                        </div>
                        <div class="bio-item">
                            <div class="bio-label">No. Peserta Ujian</div>
                            <div class="bio-val"><?= htmlspecialchars($student['nomor_peserta']) ?></div>
                        </div>
                        <div class="bio-item">
                            <div class="bio-label">Tempat, Tanggal Lahir</div>
                            <div class="bio-val"><?= htmlspecialchars($student['tempat_lahir'] . ', ' . formatTanggalIndo($student['tanggal_lahir'])) ?></div>
                        </div>
                    </div>

                    <!-- KARTU TABEL NILAI -->
                    <div class="score-card">
                        <h3 class="score-title">
                            <span><i class="fa-solid fa-file-invoice" style="margin-right: 0.5rem; color: var(--primary-light);"></i> Nilai Kelulusan</span>
                            <span style="font-size: 0.8rem; background: rgba(99, 102, 241, 0.15); padding: 0.2rem 0.6rem; border-radius: 6px; color: var(--primary-light);">Nilai Ujian</span>
                        </h3>
                        
                        <div class="table-responsive">
                            <table class="score-table">
                                <thead>
                                    <tr>
                                        <th>Mata Pelajaran</th>
                                        <th style="text-align: right;">Nilai</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="score-subject">Bahasa Indonesia</td>
                                        <td class="score-num"><?= number_format($student['nilai_indonesia'], 2) ?></td>
                                    </tr>
                                    <tr>
                                        <td class="score-subject">Matematika</td>
                                        <td class="score-num"><?= number_format($student['nilai_matematika'], 2) ?></td>
                                    </tr>
                                    <tr>
                                        <td class="score-subject">Ilmu Pengetahuan Alam (IPA)</td>
                                        <td class="score-num"><?= number_format($student['nilai_ipa'], 2) ?></td>
                                    </tr>
                                    <tr>
                                        <td class="score-subject">Ilmu Pengetahuan Sosial (IPS)</td>
                                        <td class="score-num"><?= number_format($student['nilai_ips'], 2) ?></td>
                                    </tr>
                                    <tr>
                                        <td class="score-subject">Pancasila & Kewarganegaraan</td>
                                        <td class="score-num"><?= number_format($student['nilai_ppkn'], 2) ?></td>
                                    </tr>
                                    <tr>
                                        <td class="score-subject">Pendidikan Agama</td>
                                        <td class="score-num"><?= number_format($student['nilai_agama'], 2) ?></td>
                                    </tr>
                                    <tr>
                                        <td class="score-subject">PJOK (Olahraga)</td>
                                        <td class="score-num"><?= number_format($student['nilai_pjok'], 2) ?></td>
                                    </tr>
                                    <tr>
                                        <td class="score-subject">Seni Budaya & Prakarya</td>
                                        <td class="score-num"><?= number_format($student['nilai_sbdp'], 2) ?></td>
                                    </tr>
                                    <!-- RATA-RATA -->
                                    <tr class="score-average-row">
                                        <td class="score-subject">Rata-Rata Nilai</td>
                                        <td class="score-num"><?= number_format($student['nilai_rata_rata'], 2) ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>

                </div>

                <!-- BUTTON AKSI -->
                <div class="action-buttons">
                    <a href="hasil.php?action=logout" class="btn btn-secondary">
                        <i class="fa-solid fa-arrow-left-long"></i>
                        <span>Kembali</span>
                    </a>
                    
                    <?php if ($isLulus): ?>
                        <a href="cetak-skl.php" target="_blank" class="btn btn-success">
                            <i class="fa-solid fa-print"></i>
                            <span>Cetak Surat Keterangan (SKL)</span>
                        </a>
                    <?php endif; ?>
                </div>

            </div>

        </main>

        <!-- FOOTER -->
        <footer>
            <p>&copy; <?= date('Y') ?> <?= htmlspecialchars($namaSekolah) ?>. Semua Hak Dilindungi.</p>
        </footer>

    </div>

    <!-- JS untuk Confetti jika siswa Lulus -->
    <?php if ($isLulus): ?>
        <script src="assets/js/confetti.js"></script>
    <?php endif; ?>
    <script src="assets/js/main.js"></script>
</body>
</html>
